<?php
	/*
		Cropping image from center
		@param $max_width as int 		=> decide the width of image to be cropped
		@param $max_height as int 		=> decide the height of image to be cropped
		@param $source_file as string 	=> resource file, must be gif|png|jpg type
		@param $directory as string 	=> destination to put the cropped image
		@param $new_image as string 	=> new filename for cropped image
	*/
	
	function _new_image($max_width = 0, $max_height = 0, $source_file = '', $directory = '', $new_image = '')
	{
		$imgsize = getimagesize($source_file);
		$width = $imgsize[0];
		$height = $imgsize[1];
#		$exp_ext = explode('/',image_type_to_mime_type(exif_imagetype($source_file)));
		$exp_ext = explode('/',mime_content_type($source_file));
		$ext = str_replace('e','',$exp_ext[1]);	 
		switch($exp_ext[1]){
			case 'png':
				$image_create = "imagecreatefrompng";
				$image = "imagepng";
				$quality = 8;
				break;
			case 'jpeg':
				$image_create = "imagecreatefromjpeg";
				$image = "imagejpeg";
				$quality = 800;
				break;
		}
		 
		$dst_img = imagecreatetruecolor($max_width, $max_height);
		$src_img = $image_create($source_file);
		 
		$width_new = $height * $max_width / $max_height;
		$height_new = $width * $max_height / $max_width;
		
		# if the new width is greater than the actual width of the image, then the height is too large and the rest cut off, or vice versa
		if($width_new > $width)
		{
			# cut point by height
			$h_point = (($height - $height_new) / 2);
			imagecopyresampled($dst_img, $src_img, 0, 0, 0, $h_point, $max_width, $max_height, $width, $height_new);
		}
		else
		{
			# cut point by width
			$w_point = (($width - $width_new) / 2);
			imagecopyresampled($dst_img, $src_img, 0, 0, $w_point, 0, $max_width, $max_height, $width_new, $height);
		}
		 
		# Output
		imagejpeg($dst_img, $directory.$new_image.'.'.$ext,$quality);
	 
		if($dst_img)imagedestroy($dst_img);
		if($src_img)imagedestroy($src_img);
		
		return $new_image.'.'.$ext;
	}	
?>