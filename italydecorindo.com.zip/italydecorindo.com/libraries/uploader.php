<?php
	/*
		Function to resize and rename user photo
			@param $pixel as integer
			@param $filename as string
			@param $directory as string
			@param $new_image as string
	*/
	function user_logo($pixel = 0, $filename = '', $directory = '', $new_image = '')
	{
		//$directory  = 'test-uploads/user-logo/'.$id_user.'/';
		list($wo_agent, $ho_agent) = getimagesize($filename);
		$ratio_agent = $wo_agent/$ho_agent;
		if( $ratio_agent > 1)
		{
			$w_agent = $pixel;
			$h_agent = $pixel/$ratio_agent + ($pixel - ($pixel/$ratio_agent));
		}
		else
			{
				$w_agent = $pixel*$ratio_agent + ($pixel - ($pixel*$ratio_agent));
				$h_agent = $pixel;
			}
			
		# Resample
		$src_agent = imagecreatefromjpeg($filename);
		$dst_agent = imagecreatetruecolor($w_agent,$h_agent);
		imagecopyresampled($dst_agent,$src_agent,0,0,0,0,$w_agent,$h_agent,$wo_agent,$ho_agent);
		
		# Output
		switch($pixel)
		{
			case 256:
				imagepng($dst_agent, $directory.$new_image.'.png',9);
				break;
			case 200:
				imagepng($dst_agent, $directory.'big-'.$new_image.'.png',9);
				break;
			case 100:
				imagepng($dst_agent, $directory.'middle-'.$new_image.'.png',9);
				break;
			case  60:
				imagepng($dst_agent, $directory.'small-'.$new_image.'.png',9);
				break;
		}
	}
	
	/*
		Function to resize and rename listing photo
			@param $pixel as integer
			@param $filename as string
			@param $directory as string
			@param $new_image as string
	*/
	function image_logo($width = 0, $height = 0, $filename = '', $listing_path = '', $search_path = '', $img_listing = '', $img_gallery = '')
	{
		list($wo_listing, $ho_listing) = getimagesize($filename);
		$ratio_listing = $wo_listing/$ho_listing;
		if( $ratio_listing > 1)
		{
			$w_listing = $width;
			$h_listing = $height/$ratio_listing + ($height - ($height/$ratio_listing));
		}
		else
			{
				$w_listing = $width*$ratio_listing + ($width - ($width*$ratio_listing));
				$h_listing = $height;
			}
			
		# Resample
		$src_listing = imagecreatefromjpeg($filename);
		$dst_listing = imagecreatetruecolor($w_listing,$h_listing);
		imagecopyresampled($dst_listing,$src_listing,0,0,0,0,$w_listing,$h_listing,$wo_listing,$ho_listing);
		
		# Output
		switch($width)
		{
			case 620:
				imagejpeg($dst_listing, $listing_path.'620_400-'.$img_gallery.'.jpg',800); # JPEG file
				break;
			case 200:
				imagejpeg($dst_listing, $search_path.$img_listing.'.jpg', 800); # JPEG file
				imagejpeg($dst_listing, $search_path.'big-'.$img_listing.'.jpg', 800); # JPEG file
				imagejpeg($dst_listing, $listing_path.'200_200-'.$img_gallery.'.jpg', 800); # JPEG file
				break;
			case 150:
				imagejpeg($dst_listing, $search_path.'middle-'.$img_listing.'.jpg', 800); # JPEG file
				imagegif($dst_listing, $search_path.'middle_anim-'.$img_listing.'.gif', 800); # GIF file
				break;
			case 100:
				imagejpeg($dst_listing, $search_path.'small-'.$img_listing.'.jpg', 800); # JPEG file
				break;
			case  60:
				imagejpeg($dst_listing, $listing_path.'60_60-'.$img_gallery.'.jpg', 800); # JPEG file
				break;
		}
	}
?>