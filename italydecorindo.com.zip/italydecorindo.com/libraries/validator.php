<?php
	function bb_checker($bb_strip)
	{
		$pattern = "/^[a-fA-F0-9]*$/";
		if( !preg_match($pattern, $bb_strip) )
		{
			return false;
		}
		
		return true;
	} # end function username_checker

	function email_checker($email_strip)
	{
		# check for all the non-printable codes in the standard ASCII set,
	   	# including null bytes and newlines, and exit immediately if any are found.
		if( preg_match("/[\\000-\\037]/",$email_strip) )
		{
			return false;
		}
		
		$pattern = "/^[-_a-z0-9\'+*$^&%=~!?{}]++(?:\.[-_a-z0-9\'+*$^&%=~!?{}]+)*+@(?:(?![-.])[-a-z0-9.]+(?<![-.])\.[a-z]{2,6}|\d{1,3}(?:\.\d{1,3}){3})(?::\d++)?$/iD";
		if( !preg_match($pattern, $email_strip) )
		{
			return false;
		}
		
	   	# Validate the domain exists with a DNS check
	   	# if the checks cannot be made (soft fail over to true)
		list($user,$domain) = explode('@',$email_strip);
		if( function_exists('checkdnsrr') )
		{
			if( !checkdnsrr($domain,"MX") )
			{ // Linux: PHP 4.3.0 and higher & Windows: PHP 5.3.0 and higher
				return false;
			}
		}
		elseif( function_exists("getmxrr") )
		{
			if( !getmxrr($domain, $mxhosts) )
			{
				return false;
			}
		}
		
		return true;
	} # end function validate_email
	
	function username_checker($username_strip)
	{
		# check for all the non-printable codes in the standard ASCII set,
	   	# including null bytes and newlines, and exit immediately if any are found.
		if( preg_match("/[\\000-\\037]/",$username_strip) )
		{
			return false;
		}

		$pattern = "/^[a-zA-Z0-9.]*$/";
		if( !preg_match($pattern, $username_strip) )
		{
			return false;
		}
		
		return true;
	} # end function username_checker

?>