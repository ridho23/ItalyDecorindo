<?php
	function formatting_query($data=array(), $operator='') {
		switch( $operator ) {
			case '': $op = ''; break;
			case ',': $op = ', '; break;
			case 'AND': $op = ' AND '; break;
			case 'OR': $op = ' OR '; break;
		}

		foreach($data as $item=>$val) {
			foreach($val as $k=>$each) {
				$array[$k] = $each;
			}
		}

		$json_data = json_encode($array);
		$post_data = str_replace('"',"'",str_replace(',"',$op,str_replace('":',' = ',preg_replace('/\{"|\}/','',$json_data))));
		
		return $post_data;
	}

	function get_last_id($field='', $table='') {
		$qry = "SELECT MAX(".$field.") AS ".$field." FROM ".$table;
		$sql = mysql_query($qry) or die(mysql_error());
		$last_id = mysql_fetch_assoc($sql);
		if( $last_id[$field] == 0 ) {
			$id = 1;
		} else {
			$id = $last_id[$field] + 1;
		}
		
		return $id;
	}
?>