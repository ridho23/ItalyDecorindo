<?php
    function new_image($length)
    {
		$chars = '0123456789abcdef';
		$string = '';
		for ($i = 0; $i < $length; $i++)
		{
			$pos = rand( 0, strlen($chars)-1 );
			$string .= $chars{$pos};
    	}
		
    	return $string;
    }
	
    function randomName($length)
    {
		$chars = '0123456789abcdefghijklmnopqrstuvwxyz';
		$string = '';
		for ($i = 0; $i < $length; $i++)
		{
			$pos = rand( 0, strlen($chars)-1 );
			$string .= $chars{$pos};
    	}
		
    	return $string;
    }
?>