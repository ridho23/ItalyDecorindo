<?php
	function anti_injection($data)
	{
		if( preg_match("/[\\000-\\037]/",$data) )
		{
			return false;
		}

		$filter_sql = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
		
		return $filter_sql;
	} # end function anti_injection
?>