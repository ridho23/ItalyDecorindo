<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	
	# get menu data
	$category_fields = array('id_category','category_keyword','category_name','category_logo');
	$qry_menus = "SELECT ".implode(', ',$category_fields)." FROM ".CATEGORIES." ORDER BY id_category ASC";
	$sql_menus = mysql_query($qry_menus) or die(mysql_error());

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">KATEGORI</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12 msg-box">
                <?php
                    if( isset($_GET['category']) && $_GET['category'] == 'updated' ) {
                        echo '<div class="alert alert-success">Kategori produk berhasil diubah.</div>';
                    }
                ?>
            </div>
            <div class="col-md-12">
                <div class="panel-body">
					<div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Kata Kunci</th>
                                    <th>Nama Kategori</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php while( $categories = mysql_fetch_assoc($sql_menus) ) { ?>
                            	<tr>
                                	<td><?php echo $categories['id_category']; ?></td>
                                	<td><?php echo $categories['category_keyword']; ?></td>
                                	<td><?php echo $categories['category_name']; ?></td>
                                    <td>
                                        <a data-id="<?php echo $categories['id_category']; ?>" class="btn btn-primary _detail">Detail</a>
                                    </td>
                                </tr>
							<?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- end of table responsive -->                    
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("._detail").click(function() {
		$("#dialog_container").show();
		$("#category_name").focus();
	
		var category_id = $(this).attr("data-id");
		$.post("ajax/get-detail-category.php", { id_category: category_id }, function( result ) {
			$(".ajax_form").html( result );
			$("#category_name").keyup(function() {
				var category_name = $(this).val().toLowerCase();
				$("#category_keyword").val( (category_name).replace(" ","-") );
			});

			$("#form").validate({
				rules: {
					category_name: "required"
				},
				messages: {
					category_name: { required: "Isi nama kategori" }
				}
			});

			<!-- ajax validation for photo -->
			$("#category_logo").change(function () {
				var keyword = $(this).attr("data-id");
				if(this.disabled) return alert('File upload not supported!');
				var F = this.files;
				//alert(F); return false;
				if(F && F[0]) {
					for(var i=0; i<F.length; i++)
					readImage( F[i], keyword );
				}
			});
		});
		
		$(".dialog_close").click(function() {
			$("#dialog_container").hide();
		});
	});
});
</script>

<?php include 'tpl/footer.php'; ?>