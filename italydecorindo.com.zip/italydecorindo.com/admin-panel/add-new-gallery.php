<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	include_once '../libraries/query-format.php';

	# param
	$id_item = isset($_GET['id_item']) ? $_GET['id_item'] : "";
	$item_id = formatting_query( array( array('id_item' => $id_item) ), '');
	
	# get upload config > gallery
	$qry_gall_config = "SELECT * FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'gallery-photo'";
	$sql_gall_config = mysql_query($qry_gall_config) or die(mysql_error());
	$config = mysql_fetch_assoc($sql_gall_config);
	
	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">FOTO GALERI</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li><a href="<?php echo SITE_URL.'admin-panel/gallery.php?'.str_replace(array(" ","'"),'',$item_id); ?>">Daftar Foto Galeri</a></li>
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/add-new-gallery.php?'.str_replace(array(" ","'"),'',$item_id); ?>">Tambah Foto Galeri</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="panel-body">
                                        <form action="process/save-new-gallery.php?<?php echo str_replace( array(' ',"'"),'',$item_id ); ?>" method="post" enctype="multipart/form-data" id="form">
                                            <div class="form-group">
                                                <label for="file_name">Foto Galeri *</label>
                                                <input class="form-control" type="file" name="file_name" id="file_name" data-id="gallery-photo">
                                                <p class="help-block"><i>Ukuran foto minimal <?php echo $config['min_width'].' x '.$config['min_height']; ?></i></p>
                                        		<div id="err_msg_field"></div>
                                            </div>
                                            <div class="form-group">
                                                <label for="item_caption">Caption</label>
                                                <textarea type="text" name="item_caption" id="item_caption" class="form-control" rows="3"><?php if(isset($_POST['item_caption'])) echo $_POST['item_caption']; ?></textarea>
                                            </div>
                                            <input type="submit" id="btn" class="btn btn-primary" name="btn-gallery" value="Simpan">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL.'plugins/data-tables/css/jquery.dataTables.min.css'; ?>">
<script src="<?php echo BASE_URL.'plugins/data-tables/js/jquery.dataTables.min.js'; ?> "></script>
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('#data-gallery').DataTable();

    <!-- start to validate profile form -->
    $("#form").validate({
        rules: {
            file_name: "required"
        },
        messages: {
			file_name: { required: "Pilih gambar terlebih dahulu" }
        }
    });

	<!-- ajax validation for photo -->
	$("#file_name").change(function () {
		var keyword = $(this).attr("data-id");
		if(this.disabled) return alert('File upload not supported!');
		var F = this.files;
		//alert(F); return false;
		if(F && F[0]) {
			for(var i=0; i<F.length; i++)
			readImage( F[i], keyword );
		}
	});
});
</script>

<?php include 'tpl/footer.php'; ?>