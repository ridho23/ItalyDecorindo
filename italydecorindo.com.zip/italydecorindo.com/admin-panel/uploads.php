<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	
	# upload config for slider image
	$qry_config = "SELECT * FROM ".UPLOADS_CONFIGS." ORDER BY id_upload ASC";
	$sql_config = mysql_query($qry_config) or die(mysql_error());

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">UPLOAD</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12 msg-box">
                <?php
                    if( isset($_GET['upload']) && $_GET['upload'] == 'updated' ) {
                        echo '<div class="alert alert-success">Pengaturan upload berhasil diubah.</div>';
                    }
                ?>
            </div>
            <div class="col-md-12">
                <div class="panel-body">
					<div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Kata Kunci</th>
                                    <th>Nama</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php while( $config = mysql_fetch_assoc($sql_config) ) { ?>
                            	<tr>
                                	<td><?php echo $config['id_upload']; ?></td>
                                	<td><?php echo $config['config_keyword']; ?></td>
                                	<td><?php echo $config['config_name']; ?></td>
                                    <td>
                                        <a data-id="<?php echo $config['config_keyword']; ?>" class="btn btn-primary _edit">Edit</a>
                                    </td>
                                </tr>
							<?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- end of table responsive -->                    
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<!-- load jquery and other JS file to reduce load -->
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {	
	$("._edit").click(function() {
		$("#dialog_container").show();
		$("#config_name").focus();
		
		var keyword = $(this).attr("data-id");
		$.post("ajax/get-detail-upload.php", { config_keyword: keyword }, function( result ) {
			$(".ajax_form").html( result );
			
			<!-- start to validate uploads form -->
			$("#form").validate({
				rules: {
					config_name: { required: true },
					width: {
						required: true,
						digits: true
					},
					height: {
						required: true,
						digits: true
					},
					min_width: {
						required: true,
						digits: true
					},
					min_height: {
						required: true,
						digits: true
					},
					max_width: {
						required: true,
						digits: true
					},
					max_height: {
						required: true,
						digits: true
					},
					max_size: {
						required: true,
						digits: true
					}
				},
				messages: {
					config_name: {
						required: "Isi nama kategori upload"
					},
					width: {
						required: "Tentukan ukuran lebar foto",
						digits: "Gunakan angka saja"
					},
					height: {
						required: "Tentukan ukuran tinggi foto",
						digits: "Gunakan angka saja"
					},
					min_width: {
						required: "Tentukan ukuran minimal lebar foto",
						digits: "Gunakan angka saja"
					},
					min_height: {
						required: "Tentukan ukuran minimal tinggi foto",
						digits: "Gunakan angka saja"
					},
					max_width: {
						required: "Tentukan ukuran maksimal lebar foto",
						digits: "Gunakan angka saja"
					},
					max_height: {
						required: "Tentukan ukuran maksimal tinggi foto",
						digits: "Gunakan angka saja"
					},
					max_size: {
						required: "Tentukan ukuran file gambar",
						digits: "Gunakan angka saja"
					}
				}
			});					
		});
		
		$(".dialog_close").click(function() {
			$("#dialog_container").hide();
		});
	});
});
</script>

<?php include 'tpl/footer.php'; ?>