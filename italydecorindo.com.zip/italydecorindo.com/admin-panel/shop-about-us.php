<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');

	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# get shop profile data
	$qry_shop = "SELECT id, about_us FROM ".SHOP_PROFILE;
	$sql_shop = mysql_query($qry_shop) or die(mysql_error());
	$shop = mysql_fetch_assoc($sql_shop);

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">PROFIL TOKO</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li><a href="<?php echo SITE_URL.'admin-panel/shop-profile.php'; ?>">Informasi Umum</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/shop-contact.php'; ?>">Informasi Kontak</a></li>
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/shop-about-us.php'; ?>">Tentang Kami</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php
                                        if( isset($_GET['about-us']) && !empty($_GET['about-us']) ) {
                                            echo '<div class="alert alert-success">';
                                            echo 'Informasi tentang kami berhasil diubah.';
                                            echo '</div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-12">
                                    <div class="panel-body">
                                        <form action="process/update-about-us.php?id=<?php echo $shop['id']; ?>&rdr=<?php echo $redirect; ?>" method="post" id="form">
                                            <div class="form-group">
                                                <label for="about_us">Tentang Kami *</label>
                                                <textarea class="form-control" name="about_us" id="about_us"><?php echo $shop['about_us']; ?></textarea>
                                            </div>
                                            <input type="submit" id="btn" class="btn btn-primary" name="btn-update" value="Update">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<script src="<?php echo BASE_URL.'plugins/tinymce/tinymce.min.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
	<!-- initiate tinymce -->
	tinymce.init({
		selector: 'textarea',
		height: 300
	});
	
	<!-- start to validate profile form -->
	$("#form").validate({
		rules: { about_us: "required" },
		messages: {
			about_us: { required: "Diperlukan" }
		}
	});					
});
</script>

<?php include 'tpl/footer.php'; ?>