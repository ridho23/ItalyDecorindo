<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	
	# data sent from ajax
	$category_data = formatting_query( array($_POST), ',');
	
	# get upload config
	$qry_config = "SELECT min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'index-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$get_config = mysql_fetch_assoc($sql_config);
	
	# param
	$fields = array('id_category','category_keyword','category_name','category_logo');

	# get the data
	$qry = "SELECT ".implode(', ',$fields)." FROM ".CATEGORIES." WHERE ".$category_data;
	$sql = mysql_query($qry) or die(mysql_error());
	$data = mysql_fetch_assoc($sql);
?>

<ul class="nav nav-tabs">
    <li class="active"><a>Detail Kategori</a></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade active in">
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <form action="process/update-category.php?id_category=<?php echo $data['id_category']; ?>" method="post" enctype="multipart/form-data" id="form">
                        <div class="form-group">
                            <label for="category_logo">Foto Kategori</label>
                            <input class="form-control" type="file" name="category_logo" id="category_logo" data-id="index-photo">
                            <p class="help-block"><i>Ukuran foto minimal <?php echo $get_config['min_width'].' x '.$get_config['min_height']; ?></i></p>
                            <div id="err_msg_field"></div>
                            <div class="fileupload-preview thumbnail" style="width:33%; margin-top:5px;">
                            	<img src="<?php echo UPLOADS.'index-photo/'.$data['category_logo']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="category_keyword">Kata Kunci</label>
                            <input class="form-control disabled" type="text" name="category_keyword" autocomplete="off" id="category_keyword" readonly value="<?php echo $data['category_keyword']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="category_name">Nama Menu *</label>
                            <input class="form-control" type="text" name="category_name" autocomplete="off" id="category_name" value="<?php echo $data['category_name']; ?>">
                        </div>
                        <input type="hidden" name="category_logo" value="<?php echo $data['category_logo']; ?>">
                        <input type="submit" class="btn btn-primary" name="btn-update" value="Update">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>