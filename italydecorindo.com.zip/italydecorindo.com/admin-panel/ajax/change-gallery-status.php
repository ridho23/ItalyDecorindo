<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	
	# data sent from ajax
	$exp_post = explode('-', $_POST['status']);
	$_status = $exp_post[1];
	
	switch( $_status ) {
		case 0: $status = 1; break;
		case 1: $status = 0; break;
	}

	# param
	$gallery_id = array( 'id_gallery' => $exp_post[0] );
	$gallery_id = formatting_query( array($gallery_id), '');
	
	$item_data = array(
		'date_modified' => SYS_DATE,
		'status' => $status
	);
	$item_data = formatting_query( array($item_data), ',');

	# update the data
	$qry = "UPDATE ".GALLERY." SET ".$item_data." WHERE ".$gallery_id;
	$sql = mysql_query($qry) or die(mysql_error());
	
	# for alert message
	echo $status;
?>