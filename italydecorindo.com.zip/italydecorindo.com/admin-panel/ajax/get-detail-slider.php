<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	
	# data sent from ajax
	$id_slider = $_POST['id_slider'];
	$slider_data = formatting_query( array($_POST), ',');
	
	# get upload config
	$qry_config = "SELECT min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'slider-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$get_config = mysql_fetch_assoc($sql_config);
	
	# param
	$fields = 'slider_name, slider_caption, status';

	# update the data
	$qry = "SELECT ".$fields." FROM ".SLIDERS_IMAGES." WHERE ".$slider_data;
	$sql = mysql_query($qry) or die(mysql_error());
	$data = mysql_fetch_assoc($sql);
?>

<ul class="nav nav-tabs">
    <li class="active"><a>Detail Slider</a></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade active in">
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <form action="process/update-slider.php?id_slider=<?php echo $id_slider; ?>" method="post" enctype="multipart/form-data" id="form">
                        <div class="form-group">
                            <label for="slider_name">Foto Slider</label>
                            <input class="form-control" type="file" name="slider_name" id="slider_name" data-id="slider-photo">
                            <p class="help-block"><i>Ukuran foto minimal <?php echo $get_config['min_width'].' x '.$get_config['min_height']; ?></i></p>
                            <div id="err_msg_field"></div>
                            <div class="fileupload-preview thumbnail" style="width:100%; margin-top:5px;">
                            	<img src="<?php echo UPLOADS.'slider-photo/'.$id_slider.'/'.$data['slider_name']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="slider_caption">Caption *</label>
                            <textarea name="slider_caption" id="slider_caption" rows="3" class="form-control"><?php echo trim($data['slider_caption']); ?></textarea>
                        </div>
                        <input type="hidden" name="slider_name" value="<?php echo $data['slider_name']; ?>">
                        <input type="submit" class="btn btn-primary" name="btn-update" value="Update">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>