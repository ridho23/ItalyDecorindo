<?php
	session_start();
	require('../../auth/connection.php');

	# param
	$error_count = 0;
	
	# post data sent by ajax
	$keyword = $_POST['keyword'];
	$img_width = $_POST['width'];
	$img_height = $_POST['height'];
	$img_size = $_POST['size'];
	$img_type = $_POST['type'];

	# get upload config
	$fields = 'min_width, min_height, max_width, max_height, max_size, file_type';
	$qry_config = "SELECT ".$fields." FROM ".UPLOADS_CONFIGS." WHERE config_keyword = '".$keyword."'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	$file_type = json_decode($configs['file_type'], true);
	$max_size = $configs['max_size'] * 1024 * 1024;
	foreach($file_type as $key=>$val) {
		$text[] = $key;
	}
	
	$err_msg_text = strtoupper(implode(', ', $text));

	if( $img_width < $configs['min_width'] || $img_width > $configs['max_width'] )
	{
		echo '<p class="text-danger"><b>Lebar foto kurang atau lebih dari ukuran yang telah ditentukan.</b></p>';
		$error_count++;
	}
	if( $img_height < $configs['min_height'] || $img_height > $configs['max_height'] )
	{
		echo '<p class="text-danger"><b>Tinggi foto kurang atau lebih dari ukuran yang telah ditentukan.</b></p>';
		$error_count++;
	}
	if( !in_array($img_type, $file_type) )
	{
		echo '<p class="text-danger"><b>Tipe file yang diizinkan hanya '.$err_msg_text.'.</b></p>';
		$error_count++;
	}
	if( $img_size > $max_size )
	{
		echo '<p class="text-danger"><b>Ukuran file melebihi dari nilai yang ditentukan.</b></p>';
		$error_count++;
	}
	
	echo '<input type="hidden" value="'.$error_count.'" id="error_count">';
?>