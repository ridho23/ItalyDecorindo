<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	
	# data sent from ajax
	$menu_data = formatting_query( array($_POST), ',');
	
	# param
	$menu_fields = array('id_menu','menu_keyword','menu_name','menu_url','sorter');

	# update the data
	$qry = "SELECT ".implode(', ',$menu_fields)." FROM ".MENUS." WHERE ".$menu_data;
	$sql = mysql_query($qry) or die(mysql_error());
	$data = mysql_fetch_assoc($sql);
?>

<ul class="nav nav-tabs">
    <li class="active"><a>Detail Menu</a></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade active in">
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <form action="process/update-menu.php?id_menu=<?php echo $data['id_menu']; ?>" method="post" id="form">
                        <div class="form-group">
                            <label for="menu_keyword">Kata Kunci</label>
                            <input class="form-control disabled" type="text" name="menu_keyword" autocomplete="off" id="menu_keyword" readonly value="<?php echo $data['menu_keyword']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="menu_name">Nama Menu</label>
                            <input class="form-control" type="text" name="menu_name" autocomplete="off" id="menu_name" value="<?php echo $data['menu_name']; ?>">
                        </div>
                        <?php /*if( $data['id_menu'] != 1 ) { ?>
                            <div class="form-group">
                                <label for="menu_url">URL Menu</label>
                                <input class="form-control disabled" type="text" name="menu_url" autocomplete="off" id="menu_url" readonly value="<?php echo $data['menu_url']; ?>">
                            </div>
                            <input type="hidden" name="file_name" value="<?php echo $data['menu_url']; ?>">
						<?php } */?>
                        <input type="submit" class="btn btn-primary" name="btn-update" value="Update">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>