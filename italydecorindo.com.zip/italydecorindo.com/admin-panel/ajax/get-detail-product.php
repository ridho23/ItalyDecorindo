<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	
	# data sent from ajax
	$id_product = isset($_POST['id_product']) ? $_POST['id_product'] : "";
	$product_data = formatting_query( array($_POST), '');
	
	# get upload config
	$qry_config = "SELECT min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'product-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$get_config = mysql_fetch_assoc($sql_config);
	
	# get category product
	$sql_cat = mysql_query("SELECT id_category, category_name FROM ".CATEGORIES) or die(mysql_error());
	
	# param
	$fields = 'id_product,id_category,product_keyword,product_name,product_logo';

	# get the data
	$qry = "SELECT ".$fields." FROM ".PRODUCTS." WHERE ".$product_data;
	$sql = mysql_query($qry) or die(mysql_error());
	$data = mysql_fetch_assoc($sql);
?>

<ul class="nav nav-tabs">
    <li class="active"><a>Detail Produk</a></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade active in">
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <form action="process/update-product.php?id_product=<?php echo $data['id_product']; ?>" method="post" enctype="multipart/form-data" id="form">
                        <div class="form-group">
                            <label for="product_logo">Foto Produk</label>
                            <input class="form-control" type="file" name="product_logo" id="product_logo" data-id="product-photo">
                            <p class="help-block"><i>Ukuran foto minimal <?php echo $get_config['min_width'].' x '.$get_config['min_height']; ?></i></p>
                            <div id="err_msg_field"></div>
                            <div class="fileupload-preview thumbnail" style="width:20%; margin-top:5px;">
                            	<img src="<?php echo UPLOADS.'product-photo/'.$data['id_product'].'/'.$data['product_logo']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="id_category">Kategori Produk *</label>
                            <select id="id_category" name="id_category" class="form-control">
                                <option value="">Pilih Kategori</option>
                                <?php
                                    while( $get_cat = mysql_fetch_assoc($sql_cat) ) {
                                        if( $data['id_category'] == $get_cat['id_category'] ) {
                                            $selected = 'selected';
                                        } else {
                                            $selected = '';
                                        }
                                ?>
                                    <option value="<?php echo $get_cat['id_category']; ?>" <?php echo $selected; ?>><?php echo $get_cat['category_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="product_name">Nama Produk *</label>
                            <input type="text" name="product_name" id="product_name" class="form-control" value="<?php echo $data['product_name']; ?>" autocomplete="off">
                        </div>
                        <input type="hidden" name="product_logo" value="<?php echo $data['product_logo']; ?>">
                        <input type="submit" id="btn" class="btn btn-primary" name="btn-update" value="Update">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>