<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	
	# data sent from ajax
	$get_gallery_id = isset($_POST['id_gallery']) ? $_POST['id_gallery'] : "";
	$gallery_id = array( 'id_gallery' => $get_gallery_id );
	$id_gallery = formatting_query( array($gallery_id), '');
	
	# get upload config
	$qry_config = "SELECT config_keyword, min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'gallery-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$get_config = mysql_fetch_assoc($sql_config);
	
	# param
	$fields = 'id_item, file_name, item_caption';

	# get the data
	$qry = "SELECT ".$fields." FROM ".GALLERY." WHERE ".$id_gallery;
	$sql = mysql_query($qry) or die(mysql_error());
	$data = mysql_fetch_assoc($sql);
?>

<ul class="nav nav-tabs">
    <li class="active"><a>Detail Galeri Foto</a></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade active in">
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <form action="process/update-gallery.php?id_item=<?php echo $data['id_item']; ?>&<?php echo str_replace( array(' ',"'"),'',$id_gallery ); ?>" method="post" enctype="multipart/form-data" id="form">
                        <div class="form-group">
                            <label for="file_name">Foto Produk</label>
                            <input class="form-control" type="file" name="file_name" id="file_name" data-id="gallery-photo">
                            <p class="help-block"><i>Ukuran foto minimal <?php echo $get_config['min_width'].' x '.$get_config['min_height']; ?></i></p>
                            <div id="err_msg_field"></div>
                            <div class="fileupload-preview thumbnail" style="width:40%; margin-top:5px;">
                            	<img src="<?php echo UPLOADS.$get_config['config_keyword'].'/'.$data['id_item'].'/'.$get_gallery_id.'/'.$data['file_name']; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="item_caption">Caption</label>
                            <textarea type="text" name="item_caption" id="item_caption" class="form-control" rows="3"><?php echo $data['item_caption']; ?></textarea>
                        </div>
                        <input type="hidden" name="file_name" value="<?php echo $data['file_name']; ?>">
                        <input type="submit" id="btn" class="btn btn-primary" name="btn-update" value="Update">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>