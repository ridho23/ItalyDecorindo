<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	include_once '../../libraries/anti-injection.php';
	
	# data sent from ajax
	$upload_data = formatting_query( array($_POST), ',');
	
	# get data
	$qry_upload = "SELECT * FROM ".UPLOADS_CONFIGS." WHERE ".$upload_data;
	$sql_upload = mysql_query($qry_upload) or die(mysql_error());
	$data = mysql_fetch_assoc($sql_upload);

	# param
	$file_type = json_decode($data['file_type'], true);
?>

<ul class="nav nav-tabs">
    <li class="active"><a>Pengaturan <?php echo $data['config_name']; ?></a></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade active in">
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <form action="process/update-uploads.php?config_keyword=<?php echo $data['config_keyword']; ?>" method="post" id="form">
                        <div class="form-group">
                            <label for="config_name">Nama *</label>
                            <input class="form-control" type="text" name="config_name" autocomplete="off" id="config_name" value="<?php echo $data['config_name']; ?>">
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="width">Lebar *</label>
                                    <input class="form-control" type="text" name="width" autocomplete="off" id="width" value="<?php echo $data['width']; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="height">Tinggi *</label>
                                    <input class="form-control" type="text" name="height" autocomplete="off" id="height" value="<?php echo $data['height']; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="min_width">Minimal Lebar *</label>
                                    <input class="form-control" type="text" name="min_width" autocomplete="off" id="min_width" value="<?php echo $data['min_width']; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="min_height">Minimal Tinggi *</label>
                                    <input class="form-control" type="text" name="min_height" autocomplete="off" id="min_height" value="<?php echo $data['min_height']; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="max_width">Maksimal Lebar *</label>
                                    <input class="form-control" type="text" name="max_width" autocomplete="off" id="max_width" value="<?php echo $data['max_width']; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="max_height">Maksimal Tinggi *</label>
                                    <input class="form-control" type="text" name="max_height" autocomplete="off" id="max_height" value="<?php echo $data['max_height']; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="max_size">Maksimal Ukuran File (MB) *</label>
                                    <input class="form-control" type="text" name="max_size" autocomplete="off" id="max_size" value="<?php echo $data['max_size']; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name_format">Format Nama</label>
                                    <select class="form-control" name="name_format" id="name_format">
                                    	<option value="generate" <?php if($data['name_format'] == 'generate') echo 'selected'; ?>>Generate</option>
                                    	<option value="original" <?php if($data['name_format'] == 'original') echo 'selected'; ?>>Gunakan Nama Asli</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                        	<div class="col-md-12">
                            	<label for="file_type">Tipe Gambar *</label>
                            </div>
                            <?php
								$img_type = array(
									'jpg' => 'jpeg',
									'png' => 'png',
									'gif' => 'gif'
								);
								
								foreach($img_type as $key=>$val) {
									switch( $val ) {
										case 'jpeg': $type = 'JPG'; break;
										case 'png': $type = 'PNG'; break;
										case 'gif': $type = 'GIF'; break;
									}

									if( array_key_exists($key, $file_type) ) {
							?>
                                <div class="col-md-4">
                                    <div class="form-checkbox">
                                        <input type="checkbox" name="file_type[<?php echo $key?>]" value="<?php echo $val; ?>" checked>
                                        <?php echo $type; ?>
                                    </div>
                                </div>
                            <?php } else { ?>
                                <div class="col-md-4">
                                    <div class="form-checkbox">
                                        <input type="checkbox" name="file_type[<?php echo $key?>]" value="<?php echo $val; ?>">
                                        <?php echo $type; ?>
                                    </div>
                                </div>
                            <?php } } ?>
                        </div>
                        <input type="submit" id="btn" class="btn btn-primary" name="btn-update" value="Update">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>