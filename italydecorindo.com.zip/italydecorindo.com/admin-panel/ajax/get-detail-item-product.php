<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	
	# data sent from ajax
	$item_id = isset($_POST['id_item']) ? $_POST['id_item'] : "";
	$id_item = formatting_query( array($_POST), '');
	
	# get upload config
	$qry_config = "SELECT config_keyword, min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'item-product-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$get_config = mysql_fetch_assoc($sql_config);
	
	# param
	$fields = 'id_product, item_keyword, item_name, description, item_logo';

	# get the data
	$qry = "SELECT ".$fields." FROM ".ITEMS_PRODUCTS." WHERE ".$id_item;
	$sql = mysql_query($qry) or die(mysql_error());
	$data = mysql_fetch_assoc($sql);
?>

<ul class="nav nav-tabs">
    <li class="active"><a>Detail Item Produk</a></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade active in">
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <form action="process/update-item-product.php?id_product=<?php echo $data['id_product']; ?>&<?php echo str_replace( array("'",' '),'',$id_item); ?>" method="post" enctype="multipart/form-data" id="form">
                        <div class="form-group">
                            <label for="item_logo">Foto Item Produk</label>
                            <input class="form-control" type="file" name="item_logo" id="item_logo" data-id="item-product-photo">
                            <p class="help-block"><i>Ukuran foto minimal <?php echo $get_config['min_width'].' x '.$get_config['min_height']; ?></i></p>
                            <div id="err_msg_field"></div>
                            <!--<div class="fileupload-preview thumbnail" style="width:20%; margin-top:5px;">
                            	<img src="<?php echo UPLOADS.$get_config['config_keyword'].'/'.$data['id_product'].'/'.$item_id.'/'.$data['item_logo']; ?>">
                            </div>-->
                        </div>
                        <div class="form-group">
                            <label for="item_name">Nama Item Produk *</label>
                            <input type="text" name="item_name" id="item_name" class="form-control" value="<?php echo $data['item_name']; ?>" autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="description">Deskripsi Item *</label>
                            <textarea name="description" id="description" class="form-control"><?php echo $data['description']; ?></textarea>
                        </div>
                        <input type="hidden" name="item_logo" value="<?php echo $data['item_logo']; ?>">
                        <input type="submit" id="btn" class="btn btn-primary" name="btn-update" value="Update">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>