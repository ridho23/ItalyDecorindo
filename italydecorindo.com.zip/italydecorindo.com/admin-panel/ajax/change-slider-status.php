<?php
	require '../../auth/connection.php';	
	include_once '../../libraries/query-format.php';
	
	# get config of number slider to be display
	$sql_ds = mysql_query("SELECT value FROM ".CONFIGS." WHERE config_name = 'display_slider'") or die(mysql_error());
	$display_slider = mysql_fetch_assoc($sql_ds);

	# count total slider in database
	$qry_count = "SELECT COUNT(*) AS total FROM ".SLIDERS_IMAGES." WHERE status = 1";
	$sql_count = mysql_query($qry_count) or die(mysql_error());
	$count = mysql_fetch_assoc($sql_count);

	# data sent from ajax
	$exp_post = explode('-', $_POST['status']);
	$_status = $exp_post[1];
	
	switch( $_status ) {
		case 0: $status = 1; break;
		case 1: $status = 0; break;
	}

	# param
	$slider_id = array( 'id_slider' => $exp_post[0] );
	$slider_id = formatting_query( array($slider_id), '');
	
	$slider_data = array(
		'date_modified' => SYS_DATE,
		'status' => $status
	);
	$slider_data = formatting_query( array($slider_data), ',');

	if( $status == 1 ) {
		if( $count['total'] < $display_slider['value'] ) {
			echo 'changed';
							
			# update the data
			$qry = "UPDATE ".SLIDERS_IMAGES." SET ".$slider_data." WHERE ".$slider_id;
			$sql = mysql_query($qry) or die(mysql_error());
		} else {
			echo 'unchanged';
		}
	}
	
	if( $status == 0 ) {
		echo 'changed';
			
		# update the data
		$qry = "UPDATE ".SLIDERS_IMAGES." SET ".$slider_data." WHERE ".$slider_id;
		$sql = mysql_query($qry) or die(mysql_error());
	}
?>