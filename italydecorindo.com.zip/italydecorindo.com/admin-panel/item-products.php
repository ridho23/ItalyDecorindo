<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	
	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# param
	$id_product = isset($_GET['id_product']) ? $_GET['id_product'] : "";
	
	# get products data
	$qry_items = "SELECT ".ITEMS_PRODUCTS.".* FROM ".ITEMS_PRODUCTS.", ".PRODUCTS."
				  WHERE ".ITEMS_PRODUCTS.".id_product = ".PRODUCTS.".id_product AND ".ITEMS_PRODUCTS.".id_product = '".$id_product."' ORDER BY date_add DESC";
	$sql_items = mysql_query($qry_items) or die(mysql_error());

//	header('location:'.$_SERVER['PHP_SELF'].'?id_product='.$id_product.'&item-product=updated');

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">
                	ITEM PRODUK
                    <small></small>
                </h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/item-products.php?id_product='.$id_product; ?>">Daftar Item Produk</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/add-new-item.php?id_product='.$id_product; ?>">Tambah Item Produk</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12 msg-box">
                                    <?php
                                        if( isset($_GET['product']) && $_GET['product'] == 'added' ) {
											$msg = 'Produk baru berhasil ditambahkan. Silahkan tambahkan item produk terkait.';
											
                                            echo '<div class="alert alert-success">'.$msg.'</div>';
                                        }
                                        if( isset($_GET['item-product']) ) {
											switch( $_GET['item-product'] ) {
												case 'added': $msg = 'Item Produk baru berhasil ditambahkan.'; break;
												case 'deleted': $msg = 'Item produk berhasil dihapus'; break;
												case 'updated': $msg = 'Item produk berhasil diubah'; break;
											}
											
                                            echo '<div class="alert alert-success">'.$msg.'</div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-12">
                                    <table id="data-item-products" class="display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Kata Kunci</th>
                                                <th>Nama Item</th>
                                                <th>Deskripsi</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        	while( $item = mysql_fetch_assoc($sql_items) ) {
												$descs = explode(' ', strip_tags($item['description']));
												$descs = implode(' ', array_slice( $descs, 0, 10 ) );

												switch( $item['status'] ) {
													case 0: $status = '<img src="'.BASE_URL.'img/i-inactive.png">'; break;
													case 1: $status = '<img src="'.BASE_URL.'img/i-active.png">'; break;
												}
										?>
                                        	<tr valign="top">
                                            	<td><?php echo $item['id_item']; ?></td>
                                            	<td><?php echo $item['item_keyword']; ?></td>
                                            	<td><?php echo $item['item_name']; ?></td>
                                            	<td><?php echo $descs; ?></td>
                                            	<td><a data-id="<?php echo $item['id_item'].'-'.$item['status']; ?>" class="_status"><?php echo $status; ?></a></td>
                                            	<td>
                                                    <a href="gallery.php?id_item=<?php echo $item['id_item']; ?>" class="btn btn-success">
                                                    	Detail
                                                    </a>
                                                	<a data-id="<?php echo $item['id_item']; ?>" class="btn btn-primary _edit">Edit</a>
                                                    <a href="delete-item-product.php?id_product=<?php echo $id_product; ?>&id_item=<?php echo $item['id_item']; ?>&rdr=<?php echo $redirect; ?>" class="btn btn-danger" onClick="return confirm('Hapus item produk ?');">
                                                    	Hapus
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL.'plugins/data-tables/css/jquery.dataTables.min.css'; ?>">
<script src="<?php echo BASE_URL.'plugins/data-tables/js/jquery.dataTables.min.js'; ?> "></script>
<script src="<?php echo BASE_URL.'plugins/tinymce/tinymce.min.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('#data-item-products').DataTable();
	
	$("._edit").click(function() {
		$("#dialog_container").show();
	
		var item_id = $(this).attr("data-id");
		$.post("ajax/get-detail-item-product.php", { id_item: item_id }, function( result ) {
			$(".ajax_form").html( result );
		
			<!-- initiate tinymce -->
			tinymce.init({
				selector: 'textarea',
				height: 100
			});

			<!-- start to validate profile form -->
			$("#form").validate({
				rules: {
					item_name: "required",
					description: "required"
				},
				messages: {
					item_name: { required: "Isi name item produk" },
					description: { required: "Isi deskripsi item produk" }
				}
			});

			<!-- ajax validation for photo -->
			$("#item_logo").change(function () {
				var keyword = $(this).attr("data-id");
				if(this.disabled) return alert('File upload not supported!');
				var F = this.files;
				//alert(F); return false;
				if(F && F[0]) {
					for(var i=0; i<F.length; i++)
					readImage( F[i], keyword );
				}
			});
		});
		
		$(".dialog_close").click(function() {
			$("#dialog_container").hide();
		});
	});	

	$("._status").click(function() {
		var _status = $(this).attr("data-id");
		
		$.post("ajax/change-item-status.php", { status: _status }, function( r ) {
			if( r == 1 ) {
				alert('Status product berhasil diaktifkan');
			} else {
				alert('Status product berhasil dinonaktifkan');
			}
			
			location.reload(true);
		});
	});
});
</script>

<?php include 'tpl/footer.php'; ?>