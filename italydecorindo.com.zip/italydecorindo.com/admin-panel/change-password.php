<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');

	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}
	
	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
	<!-- focus on first load -->
	$("#password").focus(); 
	
	<!-- start to validate security form -->
	$("#form").validate({
		rules: {
			password: {
				required: true,
				minlength:8
			},
			re_password: {
				required: true,
				equalTo: password
			}
		},
		messages: {
			password: {
				required: "Isi password anda",
				minlength: "Minimal 8 karakter"
			},
			re_password: {
				required: "Konfirmasi password anda",
				equalTo: "Password tidak cocok"
			}
		}
	});
});
</script>

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">PROFIL ADMIN</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li><a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>">Data Personal</a></li>
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/change-password.php'; ?>">Ganti Password</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php
                                        if( isset($_GET['password']) && $_GET['password'] == 'changed' ) {
                                            echo '<div class="alert alert-success">
													  Password anda telah berhasil diubah.
												  </div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-6">
                                    <div class="panel-body">
                                        <form action="process/update-password.php?rdr=<?php echo $redirect; ?>" method="post" id="form">
                                            <div class="form-group">
                                                <label for="password">Password Baru</label>
                                                <input class="form-control" type="password" name="password" id="password">
                                            </div>
                                            <div class="form-group">
                                                <label for="re_password">Ulangi Password</label>
                                                <input class="form-control" type="password" name="re_password" id="re_password">
                                            </div>
                                            <input type="submit" class="btn btn-primary" value="Update">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<?php include 'tpl/footer.php'; ?>