<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');

	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# get shop profile data
	$qry_shop = "SELECT id, shop_name, shop_logo, address FROM ".SHOP_PROFILE;
	$sql_shop = mysql_query($qry_shop) or die(mysql_error());
	$shop = mysql_fetch_assoc($sql_shop);

	# get upload config
	$qry_config = "SELECT min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'profile-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);
	
	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">PROFIL TOKO</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/shop-profile.php'; ?>">Informasi Umum</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/shop-contact.php'; ?>">Informasi Kontak</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/shop-about-us.php'; ?>">Tentang Kami</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php
                                        if( isset($_GET['profile']) && $_GET['profile'] == 'updated' ) {
                                            echo '<div class="alert alert-success">';
                                            echo 'Informasi umum berhasil diubah.';
                                            echo '</div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-6">
                                    <div class="panel-body">
                                        <form action="process/update-shop-profile.php?id=<?php echo $shop['id']; ?>&rdr=<?php echo $redirect; ?>" method="post" enctype="multipart/form-data" id="form">
                                            <div class="form-group">
                                                <label for="shop_logo">Logo Usaha</label>
                                                <input class="form-control" type="file" name="shop_logo" id="shop_logo" data-id="profile-photo">
                                                <p class="help-block"><i>Ukuran foto minimal <?php echo $configs['min_width'].' x '.$configs['min_height']; ?></i></p>
                                                <div id="err_msg_field"></div>
                                                <div class="fileupload-preview thumbnail" style="width:100%; margin-top:5px;">
                                                    <img src="<?php echo BASE_URL.'img/'.$shop['shop_logo']; ?>">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="shop_name">Nama Usaha *</label>
                                                <input class="form-control" type="text" autocomplete="off" name="shop_name" id="shop_name" value="<?php echo $shop['shop_name']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="address">Alamat *</label>
                                                <textarea class="form-control" name="address" id="address" rows="3"><?php echo $shop['address']; ?></textarea>
                                            </div>
                                            <input type="hidden" name="shop_logo" value="<?php echo $shop['shop_logo']; ?>">
                                            <input type="submit" id="btn" class="btn btn-primary" name="btn-update" value="Update">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<!-- load jquery and other JS file to reduce load -->
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>

<script type="text/javascript">
$(document).ready(function() {
	$("#shop_name").focus();
	
	<!-- start to validate profile form -->
	$("#form").validate({
		rules: {
			shop_name: "required",
			address: "required"
		},
		messages: {
			shop_name: { required: "Isi nama usaha anda" },
			address: { required: "Isi alamat usaha anda" }
		}
	});					

	<!-- ajax validation for photo -->
	$("#shop_logo").change(function () {
		var keyword = $(this).attr("data-id");
		if(this.disabled) return alert('File upload not supported!');
		var F = this.files;
		//alert(F); return false;
		if(F && F[0]) {
			for(var i=0; i<F.length; i++)
			readImage( F[i], keyword );
		}
	});
});
</script>

<?php include 'tpl/footer.php'; ?>