<?php
	session_start();
	require "../auth/connection.php";
	if( isset($_COOKIE[LOGGED_IN_COOKIE_NAME]) ) {
		header('location:dashboard.php');
	}

	$_ausers = array('name','username','password','status');
	
	# param for error message
	$msg = '';
	
	# process data by pressing login button
	if( isset($_POST['btn-login']) ) {
		include_once "../libraries/anti-injection.php";

		foreach($_POST as $key=>$val) {
			$each = anti_injection($val);
			
			if( $key == 'password' ) {
				$each = md5(sha1($each));
			}
			
			$temp_login[$key] = $each;

			if( $key == 'btn-login' ) {
				unset($temp_login[$key]);
			}
		}
		
		include_once '../libraries/query-format.php';
		$login_data = formatting_query( array($temp_login), 'AND');

		# get data from database
		$qry_cek = "SELECT * FROM ".AUSERS." WHERE ".$login_data;
		$sql_cek = mysql_query($qry_cek) or die(mysql_error());
		if( mysql_num_rows($sql_cek) == 1 ) {
			$user_data = mysql_fetch_assoc($sql_cek);
			
			# store user data in session
			$_SESSION['itd'] = $user_data;
			
			# set cookie
			setcookie(LOGGED_IN_COOKIE_NAME, LOGGED_IN_COOKIE_VALUE, time() + ( 7200 ), '/');
			
			header('location:dashboard.php');
		} else {
			$msg = '<p class="msg error">Email atau Password salah</p>';
		}
	}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Italy Decorindo | Login</title>
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL.'css/admin.css'; ?>">
<script src="<?php echo BASE_URL.'js/jquery-2.1.4.js'; ?>"></script>
<script>
$(document).ready(function() {
    $("#username").focus();
	
	$("#username, #password").keyup(function(){
		var _user = $("#username").val();
		var _pass = $("#password").val();
		
		if( _user == "" || _pass == "" || _pass.length < 6 )
			{ $("#btn-login").attr("disabled", true); }
		else
			{ $("#btn-login").removeAttr("disabled"); }
	});
});
</script>
</head>

<body>
<div class="container">
    <div class="login-form">
        <form action="" method="post">
            <h3>Silahkan Login</h3>
            <div class="field-area">
            	<?php echo $msg; ?>
            	<ul>
                	<li>
                    	<span><img src="<?php echo BASE_URL.'img/i-user.png'; ?>"></span>
                        <input type="text" id="username" name="username" maxlength="30" autocomplete="off" placeholder="Username" value="<?php if(isset($_POST['username'])) echo $_POST['username']; ?>">
                    </li>
                	<li>
                    	<span><img src="<?php echo BASE_URL.'img/i-pass.png'; ?>"></span>
                        <input type="password" id="password" name="password" maxlength="30" autocomplete="off" placeholder="Password">
                    </li>
                </ul>
            </div>
            <div class="submit-area">
            	<div class="pull-left"><a href="forgot-password.php">Lupa password ?</a></div>
                <div class="pull-right">
                	<input type="submit" id="btn-login" class="btn btn-login" name="btn-login" value="Login" disabled>
                </div>
            </div>
        </form>
    </div>
</div>
</body>
</html>