<?php
	session_start();
	require '../auth/connection.php';
	
	# clear session data
	session_destroy();

	# clear cookie
	unset($_COOKIE[LOGGED_IN_COOKIE_NAME]);
	setcookie(LOGGED_IN_COOKIE_NAME, '', time() - (10000), '/');
	
	#redirect
	header('location:'.SITE_URL.'admin-panel/');
?>