    </div>
    <!-- end id wrapper -->

    <div id="footer-sec">
        &copy; 1993 - <?php echo date('Y'); ?> Italydecorindo.com
    </div>    
</body>
</html>
