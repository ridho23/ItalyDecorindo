<?php
	require '../auth/connection.php';
	require 'auth.php';
	include_once '../libraries/query-format.php';

	# param
	$get_product_id = isset($_GET['id_product']) ? $_GET['id_product'] : "";
	$product_id = array( 'id_product' => $get_product_id );
	$id_product = formatting_query( array($product_id), '');

	$get_item_id = isset($_GET['id_item']) ? $_GET['id_item'] : "";
	$item_id = array( 'id_item' => $get_item_id );
	$id_item = formatting_query( array($item_id), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?'.str_replace( array("'",' '),'',$id_product).'&item-product=deleted';

	# get item product data
	$qry_get_item = "SELECT item_logo FROM ".ITEMS_PRODUCTS." WHERE ".$id_item;
	$sql_get_item = mysql_query($qry_get_item) or die(mysql_error());
	$item_data = mysql_fetch_assoc($sql_get_item);
	
	# item product path
	$item_path = '../uploads/item-product-photo/'.$get_product_id.'/'.$get_item_id.'/';
	$item_image = $item_path.$item_data['item_logo'];
		
	# get gallery data
	$qry_get_gall = "SELECT id_gallery, file_name FROM ".GALLERY." WHERE ".$id_item;
	$sql_get_gall = mysql_query($qry_get_gall) or die(mysql_error());
	while( $gall_data = mysql_fetch_assoc($sql_get_gall) ) {
		# gallery path
		$gall_full_path = '../uploads/gallery-photo/'.$get_item_id.'/'.$gall_data['id_gallery'].'/';
		$gall_path = '../uploads/gallery-photo/'.$get_item_id.'/';
		$gall_image = $gall_full_path.$gall_data['file_name'];
		
		# delete gallery photo and its own path
		@unlink($gall_image);
		rmdir($gall_full_path);
		rmdir($gall_path);

		# delete gallery data from database
		$qry_del_gall = "DELETE FROM ".GALLERY." WHERE ".$id_item;
		$sql_del_gall = mysql_query($qry_del_gall) or die(mysql_error());
	}
			
	# delete item photo and its own path
	@unlink($item_image);
	rmdir($item_path);

	# delete item data from database
	$qry_del_item = "DELETE FROM ".ITEMS_PRODUCTS." WHERE ".$id_item;
	$sql_del_item = mysql_query($qry_del_item) or die(mysql_error());

	if( $sql_del_item == true ) {
		header('location:'.$redirect);
	}
?>