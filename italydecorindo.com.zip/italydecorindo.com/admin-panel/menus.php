<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	
	# get menu data
	$menu_fields = array('id_menu','menu_keyword','menu_name','menu_url','sorter');
	$qry_menus = "SELECT ".implode(', ',$menu_fields)." FROM ".MENUS." ORDER BY id_menu ASC";
	$sql_menus = mysql_query($qry_menus) or die(mysql_error());

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">MENU</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12 msg-box">
                <?php
                    if( isset($_GET['menu']) && !empty($_GET['menu']) ) {
                        echo '<div class="alert alert-success">Menu berhasil diubah.</div>';
                    }
                ?>
            </div>
            <div class="col-md-12">
                <div class="panel-body">
					<div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Kata Kunci</th>
                                    <th>Nama Menu</th>
                                    <th>URL Menu</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php while( $menus = mysql_fetch_assoc($sql_menus) ) { ?>
                            	<tr>
                                	<td><?php echo $menus['id_menu']; ?></td>
                                	<td><?php echo $menus['menu_keyword']; ?></td>
                                	<td><?php echo $menus['menu_name']; ?></td>
                                	<td><?php echo $menus['menu_url']; ?></td>
                                    <td>
                                        <a data-id="<?php echo $menus['id_menu']; ?>" class="btn btn-primary _edit">Edit</a>
                                    </td>
                                </tr>
							<?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- end of table responsive -->                    
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {	
	$("._edit").click(function() {
		$("#dialog_container").show();
		$("#menu_name").focus();
	
		var menu_id = $(this).attr("data-id");
		$.post("ajax/get-detail-menu.php", { id_menu: menu_id }, function( result ) {
			$(".ajax_form").html( result );
			$("#menu_name").keyup(function() {
				var menu_name = $(this).val().toLowerCase();
				$("#menu_keyword").val( menu_name );
				//$("#menu_url").val( (menu_name).replace(" ","-") + '.php' );
			});
		});
		
		$(".dialog_close").click(function() {
			$("#dialog_container").hide();
		});
	});
});
</script>

<?php include 'tpl/footer.php'; ?>