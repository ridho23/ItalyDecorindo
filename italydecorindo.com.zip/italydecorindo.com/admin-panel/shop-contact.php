<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');

	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# get shop profile data
	$qry_shop = "SELECT id, email, telp_1, telp_2, mobile_1, mobile_2, fax FROM ".SHOP_PROFILE;
	$sql_shop = mysql_query($qry_shop) or die(mysql_error());
	$shop = mysql_fetch_assoc($sql_shop);

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">PROFIL TOKO</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li><a href="<?php echo SITE_URL.'admin-panel/shop-profile.php'; ?>">Informasi Umum</a></li>
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/shop-contact.php'; ?>">Informasi Kontak</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/shop-about-us.php'; ?>">Tentang Kami</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php
                                        if( isset($_GET['profile']) && !empty($_GET['profile']) ) {
                                            echo '<div class="alert alert-success">';
                                            echo 'Informasi umum berhasil diubah.';
                                            echo '</div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-6">
                                    <div class="panel-body">
                                        <form action="process/update-shop-contact.php?id=<?php echo $shop['id']; ?>&rdr=<?php echo $redirect; ?>" method="post" id="form">
                                            <div class="form-group">
                                                <label for="email">Email *</label>
                                                <input class="form-control" type="text" autocomplete="off" name="email" id="email" value="<?php echo $shop['email']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="telp_1">No. Telepon 1 *</label>
                                                <input class="form-control" type="text" autocomplete="off" name="telp_1" id="telp_1" value="<?php echo $shop['telp_1']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="telp_2">No. Telepon 2</label>
                                                <input class="form-control" type="text" autocomplete="off" name="telp_2" id="telp_2" value="<?php echo $shop['telp_2']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="mobile_1">No. HP 1 *</label>
                                                <input class="form-control" type="text" autocomplete="off" name="mobile_1" id="mobile_1" value="<?php echo $shop['mobile_1']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="mobile_2">No. HP 2</label>
                                                <input class="form-control" type="text" autocomplete="off" name="mobile_2" id="mobile_2" value="<?php echo $shop['mobile_2']; ?>">
                                            </div>
                                            <div class="form-group">
                                                <label for="fax">No. Fax</label>
                                                <input class="form-control" type="text" autocomplete="off" name="fax" id="fax" value="<?php echo $shop['fax']; ?>">
                                            </div>
                                            <input type="submit" id="btn" class="btn btn-primary" name="btn-update" value="Update">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#email").focus();
	
	<!-- start to validate profile form -->
	$("#form").validate({
		rules: {
			email: {
				required: true,
				email: true
			},
			telp_1: {
				required: true,
				digits: true
			},
			telp_2: { digits: true },
			mobile_1: {
				required: true,
				digits: true
			},
			mobile_2: { digits: true },
			fax: { digits: true }
		},
		messages: {
			email: {
				required: "Isi email anda",
				email: "Email tidak valid"
			},
			telp_1: {
				required: "Isi nomor telepon anda",
				digits: "Gunakan angka saja"
			},
			telp_2: { digits: "Gunakan angka saja" },
			mobile_1: {
				required: "Isi nomor ponsel anda",
				digits: "Gunakan angka saja"
			},
			mobile_2: { digits: "Gunakan angka saja" },
			fax: { digits: "Gunakan angka saja" }
		}
	});					
});
</script>

<?php include 'tpl/footer.php'; ?>