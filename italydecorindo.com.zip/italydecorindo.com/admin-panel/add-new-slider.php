<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');

	# get upload config
	$qry_config = "SELECT min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'slider-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);
	
	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->
        
<div id="page-wrapper">
    <div id="page-inner" class="slider">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">FOTO SLIDER</h1>
            </div>
        </div>
        <!-- /. ROW  -->
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li><a href="<?php echo SITE_URL.'admin-panel/sliders.php'; ?>">Daftar Slider</a></li>
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/add-new-slider.php'; ?>">Tambah Slider</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/slider-config.php'; ?>">Pengaturan</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="panel-body">
                                        <form action="process/save-new-slider.php" method="post" enctype="multipart/form-data" id="form">
                                            <div class="form-group">
                                                <label for="slider_name">Foto Slider *</label>
                                                <input class="form-control" type="file" name="slider_name" id="slider_name" data-id="slider-photo">
                                                <p class="help-block"><i>Ukuran foto minimal <?php echo $configs['min_width'].' x '.$configs['min_height']; ?></i></p>
                                        		<div id="err_msg_field"></div>
                                            </div>
                                            <div class="form-group">
                                                <label for="slider_caption">Caption *</label>
                                                <textarea name="slider_caption" id="slider_caption" rows="3" class="form-control"><?php if(isset($_POST['caption'])) echo $_POST['caption']; else echo ''; ?></textarea>
                                            </div>
                                            <input type="submit" class="btn btn-primary" id="btn" name="btn-slider" value="Simpan">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<!-- load jquery and other JS file to reduce load -->
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script>
    <!-- start to validate profile form -->
    $("#form").validate({
        rules: {
            slider_caption: "required",
			slider_name: "required"
        },
        messages: {
            slider_caption: { required: "Isi caption pada foto slider" },
            slider_name: { required: "Pilih gambar terlebih dahulu" }
        }
    });

	<!-- ajax validation for photo -->
	$("#slider_name").change(function () {
		var keyword = $(this).attr("data-id");
		if(this.disabled) return alert('File upload not supported!');
		var F = this.files;
		//alert(F); return false;
		if(F && F[0]) {
			for(var i=0; i<F.length; i++)
			readImage( F[i], keyword );
		}
	});
</script>

<?php include 'tpl/footer.php'; ?>