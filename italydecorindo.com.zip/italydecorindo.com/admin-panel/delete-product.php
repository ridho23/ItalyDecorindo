<?php
	require '../auth/connection.php';
	require 'auth.php';
	include_once '../libraries/query-format.php';

	# param
	$get_product_id = isset($_GET['id_product']) ? $_GET['id_product'] : "";
	$product_id = array( 'id_product' => $get_product_id );
	$id_product = formatting_query( array($product_id), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?product=deleted';	

	# get product data
	$qry_get_prod = "SELECT product_logo FROM ".PRODUCTS." WHERE ".$id_product;
	$sql_get_prod = mysql_query($qry_get_prod) or die(mysql_error());
	$prod_data = mysql_fetch_assoc($sql_get_prod);
	
	# product path
	$prod_path = '../uploads/product-photo/'.$get_product_id.'/';
	$prod_image = $prod_path.$prod_data['product_logo'];
		
	# get item product data
	$qry_get_item = "SELECT id_item, item_logo FROM ".ITEMS_PRODUCTS." WHERE ".$id_product;
	$sql_get_item = mysql_query($qry_get_item) or die(mysql_error());
	
	while( $item_data = mysql_fetch_assoc($sql_get_item) ) {
		# item product path
		$item_path = '../uploads/item-product-photo/'.$get_product_id;
		$item_full_path = '../uploads/item-product-photo/'.$get_product_id.'/'.$item_data['id_item'].'/';
		$item_image = $item_full_path.$item_data['item_logo'];
		
		# get gallery data
		$qry_get_gall = "SELECT id_gallery, file_name FROM ".GALLERY." WHERE id_item = '".$item_data['id_item']."'";
		$sql_get_gall = mysql_query($qry_get_gall) or die(mysql_error());
		
		while( $gall_data = mysql_fetch_assoc($sql_get_gall) ) {
			# gallery path
			$gall_path = '../uploads/gallery-photo/'.$item_data['id_item'];
			$gall_full_path = '../uploads/gallery-photo/'.$item_data['id_item'].'/'.$gall_data['id_gallery'].'/';
			$gall_image = $gall_full_path.$gall_data['file_name'];
			
			# delete gallery photo and its own path
			@unlink($gall_image);
			rmdir($gall_path);

			# delete gallery data from database
			$qry_del_gall = "DELETE FROM ".GALLERY." WHERE id_item = '".$item_data['id_item']."'";
			$sql_del_gall = mysql_query($qry_del_gall) or die(mysql_error());
		}
			
		# delete item photo and its own path
		@unlink($item_image);
		rmdir($item_path);

		# delete item data from database
		$qry_del_item = "DELETE FROM ".ITEMS_PRODUCTS." WHERE ".$id_product;
		$sql_del_item = mysql_query($qry_del_item) or die(mysql_error());
	}

	# delete product photo and its own path
	@unlink($prod_image);
	rmdir($prod_path);
	
	# delete product data from database
	$qry = "DELETE FROM ".PRODUCTS." WHERE ".$id_product;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>