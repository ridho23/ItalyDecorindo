<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');

	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# get upload config
	$qry_config = "SELECT config_keyword, min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'auser-logo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">PROFIL ADMIN</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>">Data Personal</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/change-password.php'; ?>">Ganti Password</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php
                                        if( isset($_GET['profile']) && !empty($_GET['profile']) ) {
                                            echo '<div class="alert alert-success">';
                                            echo 'Informasi personal berhasil diubah.';
                                            echo '</div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-6">
                                    <div class="panel-body">
                                        <form action="process/update-profile.php?rdr=<?php echo $redirect; ?>" method="post" enctype="multipart/form-data" id="form">
                                            <div class="form-group">
                                                <label for="auser_logo">Foto Profil</label>
                                                <input class="form-control" type="file" name="auser_logo" id="auser_logo" data-id="<?php echo $configs['config_keyword']; ?>">
                                                <p class="help-block"><i>Ukuran foto minimal <?php echo $configs['min_width'].' x '.$configs['min_height']; ?></i></p>
                                                <div id="err_msg_field"></div>
                                            </div>
                                            <div class="form-group">
                                                <label for="username">Username</label>
                                                <input class="form-control" type="text" value="<?php echo $_SESSION['itd']['username']; ?>" disabled>
                                            </div>
                                            <div class="form-group">
                                                <label for="name">Nama *</label>
                                                <input class="form-control" type="text" name="name" id="name" autocomplete="off" value="<?php echo $_SESSION['itd']['name']; ?>">
                                            </div>
                                            <input type="submit" id="btn" class="btn btn-primary" value="Update">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<!-- load jquery and other JS file to reduce load -->
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {                
	<!-- start to validate profile form -->
	$("#form").validate({
		rules: {
			name: { required: true }
		},
		messages: {
			name: { required: "Isi nama anda" }
		}
	});
	
	<!-- ajax validation for photo -->
	$("#auser_logo").change(function () {
		var keyword = $(this).attr("data-id");
		if(this.disabled) return alert('File upload not supported!');
		var F = this.files;
		//alert(F); return false;
		if(F && F[0]) {
			for(var i=0; i<F.length; i++)
			readImage( F[i], keyword );
		}
	});
});
</script>

<?php include 'tpl/footer.php'; ?>