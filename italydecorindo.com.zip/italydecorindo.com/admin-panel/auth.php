<?php
	if( !isset($_COOKIE[LOGGED_IN_COOKIE_NAME]) ) {
		header('location:index.php');
	}
?>