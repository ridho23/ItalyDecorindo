<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	
	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# get products data
	$qry_products = "SELECT ".PRODUCTS.".*, ".CATEGORIES.".category_name FROM ".PRODUCTS.", ".CATEGORIES."
					WHERE ".PRODUCTS.".id_category = ".CATEGORIES.".id_category ORDER BY date_add DESC";
	$sql_products = mysql_query($qry_products) or die(mysql_error());

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">LIST PRODUK</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/list-products.php'; ?>">Daftar Produk</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/add-new-product.php'; ?>">Tambah Produk</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12 msg-box">
                                    <?php
                                        if( isset($_GET['product']) ) {
											switch( $_GET['product'] ) {
												case 'deleted': $msg = 'Produk berhasil dihapus'; break;
												case 'updated': $msg = 'Produk berhasil diubah'; break;
											}
											
                                            echo '<div class="alert alert-success">'.$msg.'</div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-12">
                                    <table id="data-products" class="display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Kata Kunci</th>
                                                <th>Kategori</th>
                                                <th>Nama Produk</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        	while( $product = mysql_fetch_assoc($sql_products) ) {
												switch( $product['status'] ) {
													case 0: $status = '<img src="'.BASE_URL.'img/i-inactive.png">'; break;
													case 1: $status = '<img src="'.BASE_URL.'img/i-active.png">'; break;
												}
										?>
                                        	<tr>
                                            	<td><?php echo $product['id_product']; ?></td>
                                            	<td><?php echo $product['product_keyword']; ?></td>
                                            	<td><?php echo $product['category_name']; ?></td>
                                            	<td><?php echo $product['product_name']; ?></td>
                                            	<td><a data-id="<?php echo $product['id_product'].'-'.$product['status']; ?>" class="_status"><?php echo $status; ?></a></td>
                                            	<td>
                                                    <a href="item-products.php?id_product=<?php echo $product['id_product']; ?>" class="btn btn-success">
                                                    	Detail
                                                    </a>
                                                	<a data-id="<?php echo $product['id_product']; ?>" class="btn btn-primary _edit">Edit</a>
                                                    <a href="delete-product.php?id_product=<?php echo $product['id_product']; ?>&rdr=<?php echo $redirect; ?>" class="btn btn-danger" onClick="return confirm('Hapus produk ?');">
                                                    	Hapus
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL.'plugins/data-tables/css/jquery.dataTables.min.css'; ?>">
<!-- load jquery and other JS file to reduce load -->
<script src="<?php echo BASE_URL.'plugins/data-tables/js/jquery.dataTables.min.js'; ?> "></script>
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('#data-products').DataTable();
	
	$("._edit").click(function() {
		$("#dialog_container").show();
	
		var product_id = $(this).attr("data-id");
		$.post("ajax/get-detail-product.php", { id_product: product_id }, function( result ) {
			$(".ajax_form").html( result );

			<!-- start to validate profile form -->
			$("#form").validate({
				rules: {
					id_category: "required",
					product_name: "required"
				},
				messages: {
					id_category: { required: "Pilih kategori produk" },
					product_name: { required: "Isi nama produk" }
				}
			});

			<!-- ajax validation for photo -->
			$("#product_logo").change(function () {
				var keyword = $(this).attr("data-id");
				if(this.disabled) return alert('File upload not supported!');
				var F = this.files;
				//alert(F); return false;
				if(F && F[0]) {
					for(var i=0; i<F.length; i++)
					readImage( F[i], keyword );
				}
			});
		});
		
		$(".dialog_close").click(function() {
			$("#dialog_container").hide();
		});
	});

	$("._status").click(function() {
		var _status = $(this).attr("data-id");
		
		$.post("ajax/change-product-status.php", { status: _status }, function( r ) {
			if( r == 1 ) {
				alert('Status product berhasil diaktifkan');
			} else {
				alert('Status product berhasil dinonaktifkan');
			}
			
			location.reload(true);
		});
	});
});
</script>

<?php include 'tpl/footer.php'; ?>