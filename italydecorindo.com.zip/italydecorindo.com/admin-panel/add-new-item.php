<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');

	# param
	$id_product = isset($_GET['id_product']) ? $_GET['id_product'] : "";

	# get upload config
	$qry_config = "SELECT min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'item-product-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">TAMBAH ITEM PRODUK</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li><a href="<?php echo SITE_URL.'admin-panel/item-products.php?id_product='.$id_product; ?>">Daftar Item Produk</a></li>
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/add-new-item.php?id_product='.$id_product; ?>">Tambah Item Produk</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <form action="process/save-new-item.php?id_product=<?php echo $id_product; ?>" method="post" enctype="multipart/form-data" id="form">
                                    <div class="col-md-12">
                                        <div class="panel-body">
                                            <div class="form-group">
                                                <label for="item_name">Nama Item *</label>
                                                <input type="text" name="item_name" id="item_name" class="form-control" value="<?php if(isset($_POST['item_name'])) echo $_POST['item_name']; ?>" autocomplete="off">
                                            </div>
                                            <div class="form-group">
                                                <label for="description">Deskripsi Item *</label>
                                                <textarea name="description" id="description" class="form-control"><?php if(isset($_POST['description'])) echo $_POST['description'];; ?></textarea>
                                            </div>
                                            <div class="form-group">
                                            	<label>Klik tombol dibawah untuk menambahkan foto</label> <br>
                                                <p><i>Ukuran foto minimal <?php echo $configs['min_width'].' x '.$configs['min_height']; ?></i></p>
                                                <button type="button" id="add-photos" class="btn btn-primary" style="clear:both;">Tambah Foto</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="panel-body">
                                                <ul id="_gallery"></ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="panel-body">
                                            <input type="submit" id="btn" class="btn btn-primary" name="btn-item" value="Simpan">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<!-- load jquery and other JS file to reduce load -->
<script src="<?php echo BASE_URL.'plugins/tinymce/tinymce.min.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/reader-image-2.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
	<!-- initiate tinymce -->
	tinymce.init({
		selector: 'textarea',
		height: 200
	});
	
	<!-- focus on first load -->
	$("#item_name").focus();
	
    <!-- start to validate profile form -->
    $("#form").validate({
        rules: {
			item_name: "required",
			description: "required"
        },
        messages: {
            item_name: { required: "Isi nama item produk" },
            description: { required: "Isi deskripsi produk" }
        }
    });

	<!-- function to add many photos -->
	$("#add-photos").click(function() {
		var rows = $("#_gallery li").length;
		var row = rows + 1;	
		//alert( row );
		$("#_gallery").append(
			'<li class="col-md-4 col-sm-6">'+
				'<input type="hidden" name="no[]" value="'+ row +'">'+
				'<input type="file" name="item-logo_'+ row +'" id="item-logo_'+ row +'" class="form-control" style="margin-bottom:5px;" data-id="item-product-photo">'+
				'<div id="err_msg_field-'+ row +'"></div>'+
				'<textarea name="item-caption_'+ row +'" id="item-caption_'+ row +'" class="form-control" style="margin-bottom:5px;"></textarea>'+
				'<input type="button" class="_del btn btn-danger" value="Batal">'+
			'</li>'
		);		
		
		$("._del").click(function() {
			$(this).parent().remove();
		});

		$("#item-logo_"+ row).change(function (e) {
			var keyword = $(this).attr("data-id");
			if(this.disabled) return alert('File upload not supported!');
			var F = this.files;
			//alert(F); return false;
			if(F && F[0])
				for(var i=0; i<F.length; i++)
				readImage( F[i], row, keyword );
		});
	});
});
</script>

<?php include 'tpl/footer.php'; ?>