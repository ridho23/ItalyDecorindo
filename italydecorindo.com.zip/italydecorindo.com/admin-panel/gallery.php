<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	include_once '../libraries/query-format.php';

	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# param
	$id_item = isset($_GET['id_item']) ? $_GET['id_item'] : "";
	$item_id = formatting_query( array( array('id_item' => $id_item) ), '');
	
	# upload path
	$temp_upload_path = '../uploads/tmp-photo/';

	# get upload config > gallery
	$qry_gall_config = "SELECT * FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'gallery-photo'";
	$sql_gall_config = mysql_query($qry_gall_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_gall_config);

	# get gallery data
	$qry_gallery = "SELECT * FROM ".GALLERY." WHERE ".$item_id;
	$sql_gallery = mysql_query($qry_gallery) or die(mysql_error());

	# error param for validate photo
	$error_count = 0;
	$width_error = '';
	$height_error = '';	
	$size_error = '';
	$type_error = '';

	# process button of slider
	if( isset($_POST['btn-update']) ) {
		# param for conditional
		$id_gallery = isset($_GET['id_gallery']) ? $_GET['id_gallery'] : "";
		$gallery_id = formatting_query( array( array('id_gallery' => $id_gallery) ), '');
	
		foreach($_POST as $key=>$val) {
			include_once "../libraries/anti-injection.php";
			
			$each = anti_injection($val);
			
			$temp_gallery[$key] = $each;

			if( $key == 'btn-update' || empty($key) ) {
				unset($temp_gallery[$key]);
			}
		}

		$img_name = $_FILES['file_name']['name'];
		$img_temp = $_FILES['file_name']['tmp_name'];
		$img_size = $_FILES['file_name']['size'];
		$img_type = $_FILES['file_name']['type'];

		if( !empty($img_temp ) ) {
			$images_data = @getimagesize($img_temp);
			$img_width = $images_data[0];
			$img_height = $images_data[1];
			$gallery_images_type = json_decode($configs['file_type'], true);
			$gallery_max_size = $configs['max_size'] * 1024 * 1024;

			if( $img_width < $configs['min_width'] || $img_width > $configs['max_width'] )
			{
				$width_error = '<p class="error-msg">Lebar foto kurang atau lebih dari ukuran yang telah ditentukan.</p>';
				$error_count++;
			}
			if( $img_height < $configs['min_height'] || $img_height > $configs['max_height'] )
			{
				$height_error = '<p class="error-msg">Tinggi foto kurang atau lebih dari ukuran yang telah ditentukan.</p>';
				$error_count++;
			}
			if( !in_array($img_type, $gallery_images_type) )
			{
				$type_error = '<p class="error-msg">Tipe file yang diizinkan hanya JPG, PNG, dan GIF.</p>';
				$error_count++;
			}
			if( $img_size > $gallery_max_size )
			{
				$size_error = '<p class="error-msg">Ukuran file melebihi dari nilai yang ditentukan.</p>';
				$error_count++;
			}

			if( $error_count == 0 ) {
				if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
					$temp_photo = $temp_upload_path.$img_name;
					
					# name method
					switch( $configs['name_format'] )
					{
						case 'generate':
							include_once "../libraries/random-generator.php";
							$new_name_file_name = new_image(10);
							break;
						case 'original':
							$new_name_file_name = strtolower($img_name);
							break;
					}
					
					# folder to save all photo
					$gallery_photo_path = '../uploads/'.$configs['config_keyword'].'/'.$id_item.'/'.$id_gallery.'/';
					if( !is_dir($gallery_photo_path) ) {
						umask(0);
						mkdir( $gallery_photo_path, 0777, true);
					}
					
					# delete old photo
					@unlink($gallery_photo_path.$temp_gallery['file_name']);
					
					include_once "../libraries/image-cropper.php";
					# crop images for member photo
					$_file_name = _new_image($configs['width'], $configs['height'], $temp_photo, $gallery_photo_path, $new_name_file_name);
					$temp_gallery['file_name'] = $_file_name;
					@unlink($temp_photo);
				}
			}
		}

		if( $error_count == 0 ) {
			include_once '../libraries/query-format.php';

			# param
			$additional = array( 'date_modified' => SYS_DATE );
			$gallery_data = formatting_query( array($additional, $temp_gallery), ',');
			
			# update the data
			$qry = "UPDATE ".GALLERY." SET ".$gallery_data." WHERE ".$gallery_id;
			$sql = mysql_query($qry) or die(mysql_error());
			if( $sql == true ) {
				header('location:'.$_SERVER['PHP_SELF'].'?'.str_replace(array(" ","'"),'',$item_id).'&gallery=updated');
			}
		}
	}
	
	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">FOTO GALERI</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/gallery.php?'.str_replace(array(" ","'"),'',$item_id); ?>">Daftar Foto Galeri</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/add-new-gallery.php?'.str_replace(array(" ","'"),'',$item_id); ?>">Tambah Foto Galeri</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12 msg-box">
                                    <?php
                                        if( isset($_GET['gallery']) ) {
                                            switch( $_GET['gallery'] ) {
                                                case 'added': $msg = 'Foto galeri baru berhasil ditambahkan.'; break;
                                                case 'deleted': $msg = 'Foto galeri berhasil dihapus'; break;
                                                case 'updated': $msg = 'Foto galeri berhasil diubah'; break;
                                            }
                                            
                                            echo '<div class="alert alert-success">'.$msg.'</div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-12">
                                    <table id="data-gallery" class="display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Gambar</th>
                                                <th>Caption</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $no = 1;
                                            while( $gallery = mysql_fetch_assoc($sql_gallery) ) {
                                                switch( $gallery['status'] ) {
                                                    case 0: $status = '<img src="'.BASE_URL.'img/i-inactive.png">'; break;
                                                    case 1: $status = '<img src="'.BASE_URL.'img/i-active.png">'; break;
                                                }
                                            
                                                $gall_image = UPLOADS.$configs['config_keyword'].'/'.$id_item.'/'.$gallery['id_gallery'].'/'.$gallery['file_name'];
                                        ?>
                                            <tr valign="top">
                                                <td><?php echo $no; ?></td>
                                                <td><img class="img-resonsive" src="<?php echo $gall_image; ?>" width="100"></td>
                                                <td><?php echo $gallery['item_caption']; ?></td>
                                                <td><a data-id="<?php echo $gallery['id_gallery'].'-'.$gallery['status']; ?>" class="_status"><?php echo $status; ?></a></td>
                                                <td>
                                                    <a data-id="<?php echo $gallery['id_gallery']; ?>" class="btn btn-primary _edit">Edit</a>
                                                    <a href="delete-gallery.php?id_gallery=<?php echo $gallery['id_gallery']; ?>&<?php echo str_replace(array(' ',"'"),'',$item_id); ?>&rdr=<?php echo $redirect; ?>" class="btn btn-danger" onClick="return confirm('Hapus foto galeri ?');">
                                                        Hapus
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php $no++; } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL.'plugins/data-tables/css/jquery.dataTables.min.css'; ?>">
<script src="<?php echo BASE_URL.'plugins/data-tables/js/jquery.dataTables.min.js'; ?> "></script>
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('#data-gallery').DataTable();

	$("._edit").click(function() {
		$("#dialog_container").show();
	
		var _id_gallery = $(this).attr("data-id");
		
		$.post("ajax/get-detail-gallery.php", { id_gallery: _id_gallery }, function( result ) {
			$(".ajax_form").html( result );

			<!-- ajax validation for photo -->
			$("#file_name").change(function () {
				var keyword = $(this).attr("data-id");
				if(this.disabled) return alert('File upload not supported!');
				var F = this.files;
				//alert(F); return false;
				if(F && F[0]) {
					for(var i=0; i<F.length; i++)
					readImage( F[i], keyword );
				}
			});
		});
		
		$(".dialog_close").click(function() {
			$("#dialog_container").hide();
		});
	});	

	$("._status").click(function() {
		var _status = $(this).attr("data-id");
		
		$.post("ajax/change-gallery-status.php", { status: _status }, function( r ) {
			if( r == 1 ) {
				alert('Status foto galeri berhasil diaktifkan');
			} else {
				alert('Status foto galeri berhasil dinonaktifkan');
			}
			
			location.reload(true);
		});
	});
});
</script>

<?php include 'tpl/footer.php'; ?>