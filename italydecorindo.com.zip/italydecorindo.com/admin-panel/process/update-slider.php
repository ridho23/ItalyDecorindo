<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_slider_id = $_GET['id_slider'];
	$id_slider = array('id_slider' => $get_slider_id);
	$slider_data = formatting_query( array( $id_slider ), '');

	$redirect = SITE_URL.'admin-panel/sliders.php?slider=updated';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'slider-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$slider_photo_path = '../../uploads/'.$configs['config_keyword'].'/'.$get_slider_id.'/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_slider[$key] = $each;

		if( $key == 'btn-update' ) {
			unset($temp_slider[$key]);
		}
	}

	$img_name = $_FILES['slider_name']['name'];
	$img_temp = $_FILES['slider_name']['tmp_name'];
	$img_size = $_FILES['slider_name']['size'];
	$img_type = $_FILES['slider_name']['type'];

	if( !empty( $img_temp ) ) {
		if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
			$temp_photo = $temp_upload_path.$img_name;
			
			# name method
			switch( $configs['name_format'] )
			{
				case 'generate':
					include_once "../../libraries/random-generator.php";
					$slider_name = new_image(10);
					break;
				case 'original':
					$slider_name = strtolower($img_name);
					break;
			}
			
			# folder to save all photo
			if( !is_dir($slider_photo_path) ) {
				umask(0);
				mkdir( $slider_photo_path, 0777, true);
			}
			
			include_once "../../libraries/image-cropper.php";
			
			# crop images for member photo
			$slider_name = _new_image($configs['width'], $configs['height'], $temp_photo, $slider_photo_path, $slider_name);
			@unlink($slider_photo_path.$temp_slider['slider_name']);
			@unlink($temp_photo);
			$temp_slider['slider_name'] = $slider_name;
		}
	} else {
		$temp_slider['slider_name'];
	}

	$additional = array( 'date_modified' => SYS_DATE );
	$profile_data = formatting_query( array($additional, $temp_slider), ',');
	
	# update the data
	$qry = "UPDATE ".SLIDERS_IMAGES." SET ".$profile_data." WHERE ".$slider_data;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>