<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_slider_id = get_last_id('id_slider', SLIDERS_IMAGES);
	$id_slider = array('id_slider' => $get_slider_id);

	$redirect = SITE_URL.'admin-panel/sliders.php?slider=added';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'slider-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# get config of number slider to be display
	$sql_ds = mysql_query("SELECT value FROM ".CONFIGS." WHERE config_name = 'display_slider'") or die(mysql_error());
	$display_slider = mysql_fetch_assoc($sql_ds);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$slider_photo_path = '../../uploads/'.$configs['config_keyword'].'/'.$get_slider_id.'/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_slider[$key] = $each;

		if( $key == 'btn-slider' ) {
			unset($temp_slider[$key]);
		}
	}

	$img_name = $_FILES['slider_name']['name'];
	$img_temp = $_FILES['slider_name']['tmp_name'];
	$img_size = $_FILES['slider_name']['size'];
	$img_type = $_FILES['slider_name']['type'];

	if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
		$temp_photo = $temp_upload_path.$img_name;
		
		# name method
		switch( $configs['name_format'] )
		{
			case 'generate':
				include_once "../../libraries/random-generator.php";
				$slider_name = new_image(10);
				break;
			case 'original':
				$slider_name = strtolower($img_name);
				break;
		}
		
		# folder to save all photo
		if( !is_dir($slider_photo_path) ) {
			umask(0);
			mkdir( $slider_photo_path, 0777, true);
		}
		
		include_once "../../libraries/image-cropper.php";
		# crop images for member photo
		$slider_name = _new_image($configs['width'], $configs['height'], $temp_photo, $slider_photo_path, $slider_name);
		@unlink($temp_photo);
	}

	# count total slider in database
	$qry_count = "SELECT COUNT(*) AS total FROM ".SLIDERS_IMAGES;
	$sql_count = mysql_query($qry_count) or die(mysql_error());
	$count = mysql_fetch_assoc($sql_count);

	# get last sorter value from active slider
	$qry_get_sorter = "SELECT MAX(sorter) AS sorter FROM ".SLIDERS_IMAGES;
	$sql_get_sorter = mysql_query($qry_get_sorter) or die(mysql_error());
	$sorter_data = mysql_fetch_assoc($sql_get_sorter);
	$sorter = $sorter_data['sorter'] + 1;
	
	if( $count['total'] > $display_slider['value'] )
		{ $status = 0; }
	else
		{ $status = 1; }

	$additional = array(
		'date_add' => SYS_DATE,
		'slider_name' => $slider_name,
		'status' => $status,
		'sorter' => $sorter
	);

	$profile_data = formatting_query( array($id_slider, $additional, $temp_slider), ',');
	
	# update the data
	$qry = "INSERT INTO ".SLIDERS_IMAGES." SET ".$profile_data;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>