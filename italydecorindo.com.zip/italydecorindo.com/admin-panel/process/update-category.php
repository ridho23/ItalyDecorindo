<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_cat_id = $_GET['id_category'];
	$category_id = array('id_category' => $get_cat_id);
	$id_category = formatting_query( array( $category_id ), '');

	$redirect = SITE_URL.'admin-panel/categories.php?category=updated';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'index-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$category_photo_path = '../../uploads/'.$configs['config_keyword'].'/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_category[$key] = $each;

		if( $key == 'btn-update' ) {
			unset($temp_category[$key]);
		}
	}

	$img_name = $_FILES['category_logo']['name'];
	$img_temp = $_FILES['category_logo']['tmp_name'];
	$img_size = $_FILES['category_logo']['size'];
	$img_type = $_FILES['category_logo']['type'];

	if( !empty( $img_temp ) ) {
		if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
			$temp_photo = $temp_upload_path.$img_name;
			
			# name method
			switch( $configs['name_format'] )
			{
				case 'generate':
					include_once "../../libraries/random-generator.php";
					$new_name_category_logo = new_image(10);
					break;
				case 'original':
					$new_name_category_logo = strtolower($img_name);
					break;
			}
			
			# folder to save all photo
			if( !is_dir($category_photo_path) ) {
				umask(0);
				mkdir( $category_photo_path, 0777, true);
			}
			
			include_once "../../libraries/image-cropper.php";
			
			# crop images for member photo
			$category_logo = _new_image($configs['width'], $configs['height'], $temp_photo, $category_photo_path, $new_name_category_logo);
			@unlink($category_photo_path.$temp_category['category_logo']);
			@unlink($temp_photo);
			$temp_category['category_logo'] = $category_logo;
		}
	} else {
		$temp_category['category_logo'];
	}

	$category_data = formatting_query( array($temp_category), ',');
	
	# update the data
	$qry = "UPDATE ".CATEGORIES." SET ".$category_data." WHERE ".$id_category;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>