<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$auser_data = array('auser_id' => $_SESSION['itd']['auser_id']);
	$id_auser = formatting_query( array($auser_data), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?profile=updated';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'auser-logo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$auser_photo_path = '../../uploads/'.$configs['config_keyword'].'/'.$_SESSION['itd']['auser_id'].'/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_profile[$key] = $each;

		if( $key == 'btn-update' ) {
			unset($temp_profile[$key]);
		}
	}

	$img_name = $_FILES['auser_logo']['name'];
	$img_temp = $_FILES['auser_logo']['tmp_name'];
	$img_size = $_FILES['auser_logo']['size'];
	$img_type = $_FILES['auser_logo']['type'];

	if( empty($img_temp ) ) {
		$auser_logo = $_SESSION['itd']['auser_logo'];
	} else {
		if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
			$temp_photo = $temp_upload_path.$img_name;
			
			# name method
			switch( $configs['name_format'] )
			{
				case 'generate':
					include_once "../../libraries/random-generator.php";
					$auser_logo = new_image(10);
					break;
				case 'original':
					$auser_logo = strtolower($img_name);
					break;
			}
			
			# folder to save all photo
			if( !is_dir($auser_photo_path) ) {
				umask(0);
				mkdir( $auser_photo_path, 0777, true);
			}
			
			include_once "../../libraries/image-cropper.php";
			# crop images for member photo
			$auser_logo = _new_image($configs['width'], $configs['height'], $temp_photo, $auser_photo_path, $auser_logo);
			@unlink($temp_photo);
			@unlink($auser_photo_path.$_SESSION['itd']['auser_logo']);
			$_SESSION['itd']['auser_logo'] = '';
		}
	}

	$additional = array(
		'date_modified' => SYS_DATE,
		'auser_logo' => $auser_logo
	);

	$temp_profile = array_merge($additional, $temp_profile);
	$profile_data = formatting_query( array($temp_profile), ',');
	
	# update the data
	$qry = "UPDATE ".AUSERS." SET ".$profile_data." WHERE ".$id_auser;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		foreach( $temp_profile as $key=>$val ){
			$_SESSION['itd'][$key] = $val;
		}

		header('location:'.$redirect);
	}
?>