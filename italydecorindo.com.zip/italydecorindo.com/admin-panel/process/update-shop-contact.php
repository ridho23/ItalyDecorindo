<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_shop_id = $_GET['id'];
	$shop_id = array('id' => $get_shop_id);
	$id_menu = formatting_query( array( $shop_id ), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?profile=updated';
		
	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);

		$temp_shop[$key] = $each;

		if( $key == 'btn-update' || empty($each) ) {
			unset($temp_shop[$key]);
		}
	}

	$additional = array( 'date_modified' => SYS_DATE );
	$shop_data = formatting_query( array($additional, $temp_shop), ',');
	
	# update the data
	$qry = "UPDATE ".SHOP_PROFILE." SET ".$shop_data." WHERE ".$id_menu;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>