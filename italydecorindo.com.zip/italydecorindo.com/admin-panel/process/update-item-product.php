<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_product_id = isset($_GET['id_product']) ? $_GET['id_product'] : "";
	$id_product = array('id_product' => $get_product_id);
	$product_data = formatting_query( array( $id_product ), '');

	$get_item_id = isset($_GET['id_item']) ? $_GET['id_item'] : "";
	$id_item = array('id_item' => $get_item_id);
	$item_data = formatting_query( array( $id_item ), '');

	$redirect = SITE_URL.'admin-panel/item-products.php?'.str_replace( array("'",' '),'',$product_data).'&item-product=updated';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'item-product-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$item_photo_path = '../../uploads/'.$configs['config_keyword'].'/'.$get_product_id.'/'.$get_item_id.'/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_item[$key] = $each;

		if( $key == 'btn-update' ) {
			unset($temp_item[$key]);
		}
	}

	$img_name = $_FILES['item_logo']['name'];
	$img_temp = $_FILES['item_logo']['tmp_name'];
	$img_size = $_FILES['item_logo']['size'];
	$img_type = $_FILES['item_logo']['type'];

	if( !empty( $img_temp ) ) {
		if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
			$temp_photo = $temp_upload_path.$img_name;
			
			# name method
			switch( $configs['name_format'] )
			{
				case 'generate':
					include_once "../../libraries/random-generator.php";
					$item_logo = new_image(10);
					break;
				case 'original':
					$item_logo = strtolower($img_name);
					break;
			}
			
			# folder to save all photo
			if( !is_dir($item_photo_path) ) {
				umask(0);
				mkdir( $item_photo_path, 0777, true);
			}
			
			include_once "../../libraries/image-cropper.php";
			
			# crop images for member photo
			$item_logo = _new_image($configs['width'], $configs['height'], $temp_photo, $item_photo_path, $item_logo);
			@unlink($item_photo_path.$temp_item['item_logo']);
			@unlink($temp_photo);
			$temp_item['item_logo'] = $item_logo;
		}
	} else {
		$temp_item['item_logo'];
	}

	$keyword = strtolower( str_replace(' ','-', $temp_item['item_name']) );
	$additional = array(
		'date_modified' => SYS_DATE,
		'item_keyword' => $keyword
	);
	$profile_data = formatting_query( array($additional, $temp_item), ',');
	
	# update the data
	$qry = "UPDATE ".ITEMS_PRODUCTS." SET ".$profile_data." WHERE ".$product_data;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>