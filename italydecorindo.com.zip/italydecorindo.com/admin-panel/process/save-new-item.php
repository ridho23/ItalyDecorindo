<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$id_product = isset($_GET['id_product']) ? $_GET['id_product'] : "";
	$get_item_id = get_last_id('id_item', ITEMS_PRODUCTS);
	$id_item = array('id_item' => $get_item_id);

	$redirect = SITE_URL.'admin-panel/item-products.php?id_product='.$id_product.'&item-product=added';
	
	$fields = 'config_keyword, width, height, name_format';
	# get upload config > item products
	$qry_config = "SELECT ".$fields." FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'item-product-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# get upload config > gallery
	$qry_gall_config = "SELECT ".$fields." FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'gallery-photo'";
	$sql_gall_config = mysql_query($qry_gall_config) or die(mysql_error());
	$gall_configs = mysql_fetch_assoc($sql_gall_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$slider_photo_path = '../../uploads/'.$configs['config_keyword'].'/'.$get_item_id.'/';

	# process
	if( isset($_POST['no']) ) {
		foreach($_POST['no'] as $no)
		{
			$img_tmp	= $_FILES['item-logo_'.$no]['tmp_name'];
			$img_name	= $_FILES['item-logo_'.$no]['name'];
			$img_size	= $_FILES['item-logo_'.$no]['size'];
			$img_type	= $_FILES['item-logo_'.$no]['type'];
			$caption	= anti_injection($_POST['item-caption_'.$no]);
		
			# move uploaded photo to temporary directory
			$upload_photo = move_uploaded_file($img_tmp, $temp_upload_path.$img_name);
			if( $upload_photo == true )
			{
				# get the uploaded photo in temporary directory
				$temp_photo = $temp_upload_path.$img_name;

				# name format
				switch( $gall_configs['name_format'] )
				{
					case 'generate':
						include_once "../../libraries/random-generator.php";
						$item_logo_name = new_image(10);
						$gallery_file_name = new_image(10);
						break;
					case 'original_name':
						$item_logo_name = strtolower($img_name);
						$gallery_file_name = strtolower($img_name);
						break;
				}
				
				# param
				$id_gallery = get_last_id('id_gallery', GALLERY);

				# get last sorter value from gallery
				$qry_get_sorter = "SELECT MAX(sorter) AS sorter FROM ".GALLERY;
				$sql_get_sorter = mysql_query($qry_get_sorter) or die(mysql_error());
				$sorter_data = mysql_fetch_assoc($sql_get_sorter);
				if( $sorter_data['sorter'] == 0 ) {
					$sorter = 1;
				} else {
					$sorter = $sorter_data['sorter'] + 1;
				}

				# if upload path, doesn't exists, create the directory
				$item_path = '../../uploads/'.$configs['config_keyword'].'/'.$id_product.'/'.$get_item_id.'/';
				$gallery_path  = '../../uploads/'.$gall_configs['config_keyword'].'/'.$get_item_id.'/'.$id_gallery.'/';
				if( !is_dir($item_path) || !is_dir($gallery_path) )
				{
					umask(0);
					mkdir($item_path, 0777, true);
					mkdir($gallery_path, 0777, true);
				}
				
				# crop and being a gallery and item product photo
				include_once "../../libraries/image-cropper.php";
				$item_logo = _new_image($configs['width'], $configs['height'], $temp_photo, $item_path, $item_logo_name);
				$file_name = _new_image($gall_configs['width'], $gall_configs['height'], $temp_photo, $gallery_path, $gallery_file_name);

				# array data to be saved in database
				$gall_data = array(
					'id_gallery' => $id_gallery,
					'id_item' => $get_item_id,
					'date_add' => SYS_DATE,
					'file_name' => $file_name,
					'item_caption' => $caption,
					'status' => 1,
					'sorter' => $sorter
				);
				
				$gallery_data = formatting_query( array($gall_data), ',');

				# save to gallery table
				$qry_save_gal = "INSERT INTO ".GALLERY." SET ".$gallery_data;
				$sql_save_gal = mysql_query($qry_save_gal) or die(mysql_error());
				
				@unlink($temp_photo);
			}
			# end process of uploaded photo
		}
		# end of foreach
		
		# save item-product-data
		$item_name = anti_injection($_POST['item_name']);
		$item_keyword = strtolower(str_replace(' ','-',$item_name));
		$description = $_POST['description'];

		$item_data = array(
			'id_item' => $get_item_id,
			'id_product' => $id_product,
			'date_add' => SYS_DATE,
			'item_keyword' => $item_keyword,
			'item_name' => ucwords($item_name),
			'description' => $description,
			'item_logo' => $item_logo,
			'status' => 1
		);
		
		$item_prod_data = formatting_query( array($item_data), ',');

		# save to gallery table
		$qry_save_item = "INSERT INTO ".ITEMS_PRODUCTS." SET ".$item_prod_data;
		$sql_save_item = mysql_query($qry_save_item) or die(mysql_error());
		if( $sql_save_item == true )
		{
			foreach( glob($item_path.'*.jpg') as $index )
			{
				$exp_index = explode('/',$index);
				$photo = end($exp_index);

				if($photo != $item_logo) @unlink($item_path.$photo);
			}

			header('location:'.$redirect);
		}
	}
?>