<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_id_config = array( 'id_config' => $_GET['id_config'] );
	$id_config = formatting_query( array($get_id_config), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?display_slider=updated';
	
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_slider[$key] = $each;

		if( $key == 'btn-update' ) {
			unset($temp_slider[$key]);
		}
	}

	$config_data = formatting_query( array($temp_slider), '');
	
	# update the data
	$qry = "UPDATE ".CONFIGS." SET ".$config_data." WHERE ".$id_config;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>