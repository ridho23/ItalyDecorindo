<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$config_keyword = isset($_GET['config_keyword']) ? $_GET['config_keyword'] : "";
	$config_key = array('config_keyword' => $config_keyword);
	$keyword = formatting_query( array( $config_key ), '');

	$redirect = SITE_URL.'admin-panel/uploads.php?upload=updated';

	# process
	foreach($_POST as $key=>$val) {
		$temp_upload[$key] = $val;

		if( $key == 'btn-update' || $key == 'file_type' ) {
			unset($temp_upload[$key]);
		}
	}

	$upload_data = formatting_query( array($temp_upload), ',');
	
	# update the data
	$qry = "UPDATE ".UPLOADS_CONFIGS." SET ".$upload_data." WHERE ".$keyword;
	$sql = mysql_query($qry) or die(mysql_error());
	
	if( $sql == true ) {
		# update the file type specially
		$file_type = stripslashes(json_encode($_POST['file_type'], true));
		$qry_file_type = "UPDATE ".UPLOADS_CONFIGS." SET file_type = '".$file_type."' WHERE ".$keyword;
		$sql_file_type = mysql_query($qry_file_type) or die(mysql_error());
		
		if( $sql_file_type == true ) {
			header('location:'.$redirect);
		}
	}
?>