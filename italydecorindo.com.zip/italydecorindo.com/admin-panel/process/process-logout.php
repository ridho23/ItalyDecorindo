<?php
	session_start();
	require_once '../../auth/connection.php';

	# param
	$auser_data = array('auser_id' => $_SESSION['itd']['auser_id']);
	$id_auser = formatting_query( array($auser_data), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?password=changed';
	
	# process button of security
//	if( isset($_POST['btn-update']) ) {
		foreach($_POST as $key=>$val) {
			$each = anti_injection($val);
			
			if( $key == 'password' ) {
				$each = md5(sha1($each));
			}
			
			$temp_security[$key] = $each;

			if( $key != 'password' ) {
				unset($temp_security[$key]);
			}
		}

		$additional = array('date_modified' => SYS_DATE );
		$temp_security = array_merge($additional, $temp_security);
		$security_data = formatting_query( array($temp_security), ',');
		
		# update the data
		$qry = "UPDATE ".AUSERS." SET ".$security_data." WHERE ".$id_auser;
		$sql = mysql_query($qry) or die(mysql_error());
		if( $sql == true ) {
			foreach( $temp_security as $key=>$val ){
				$_SESSION['itd'][$key] = $val;
			}
			
//			$redirect = $_SERVER['PHP_SELF'].'?password=changed';
			header('location:'.$redirect);
		}
//	}
?>