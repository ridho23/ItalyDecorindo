<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_product_id = get_last_id('id_product', PRODUCTS);
	$id_product = array('id_product' => $get_product_id);

	$redirect = SITE_URL.'admin-panel/item-products.php?product=added';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'product-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$product_photo_path = '../../uploads/'.$configs['config_keyword'].'/'.$get_product_id.'/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_product[$key] = $each;

		if( $key == 'btn-product' ) {
			unset($temp_product[$key]);
		}
	}

	$img_name = $_FILES['product_logo']['name'];
	$img_temp = $_FILES['product_logo']['tmp_name'];
	$img_size = $_FILES['product_logo']['size'];
	$img_type = $_FILES['product_logo']['type'];

	if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
		$temp_photo = $temp_upload_path.$img_name;
		
		# name method
		switch( $configs['name_format'] )
		{
			case 'generate':
				include_once "../../libraries/random-generator.php";
				$product_logo = new_image(10);
				break;
			case 'original':
				$product_logo = strtolower($img_name);
				break;
		}
		
		# folder to save all photo
		if( !is_dir($product_photo_path) ) {
			umask(0);
			mkdir( $product_photo_path, 0777, true);
		}
		
		include_once "../../libraries/image-cropper.php";
		# crop images for member photo
		$product_logo = _new_image($configs['width'], $configs['height'], $temp_photo, $product_photo_path, $product_logo);
		@unlink($temp_photo);
	}

	$keyword = strtolower( str_replace(' ','-', $temp_product['product_name']) );
	$additional = array(
		'date_add' => SYS_DATE,
		'product_keyword' => $keyword,
		'product_logo' => $product_logo,
		'status' => 1
	);

	$product_data = formatting_query( array($id_product, $additional, $temp_product), ',');
	
	# update the data
	$qry = "INSERT INTO ".PRODUCTS." SET ".$product_data;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>