<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_gallery_id = get_last_id('id_gallery', GALLERY);
	$gallery_id = array('id_gallery' => $get_gallery_id);
	$id_gallery = formatting_query( array($gallery_id),'' );

	$get_item_id = isset($_GET['id_item']) ? $_GET['id_item'] : "";
	$item_id = array('id_item' => $get_item_id);
	$id_item = formatting_query( array($item_id),'' );

	$redirect = SITE_URL.'admin-panel/gallery.php?'.str_replace( array(' ',"'"),'',$id_item ).'&gallery=added';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'gallery-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$gallery_photo_path = '../../uploads/'.$configs['config_keyword'].'/'.$get_item_id.'/'.$get_gallery_id.'/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_gallery[$key] = $each;

		if( $key == 'btn-gallery' ) {
			unset($temp_gallery[$key]);
		}
	}

	$img_name = $_FILES['file_name']['name'];
	$img_temp = $_FILES['file_name']['tmp_name'];
	$img_size = $_FILES['file_name']['size'];
	$img_type = $_FILES['file_name']['type'];

	if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
		$temp_photo = $temp_upload_path.$img_name;
		
		# name method
		switch( $configs['name_format'] )
		{
			case 'generate':
				include_once "../../libraries/random-generator.php";
				$file_name = new_image(10);
				break;
			case 'original':
				$file_name = strtolower($img_name);
				break;
		}
		
		# folder to save all photo
		if( !is_dir($gallery_photo_path) ) {
			umask(0);
			mkdir( $gallery_photo_path, 0777, true);
		}
		
		include_once "../../libraries/image-cropper.php";
		# crop images for member photo
		$file_name = _new_image($configs['width'], $configs['height'], $temp_photo, $gallery_photo_path, $file_name);
		@unlink($temp_photo);
	}

	# get last sorter value from active slider
	$qry_get_sorter = "SELECT MAX(sorter) AS sorter FROM ".GALLERY." WHERE ".$id_item;
	$sql_get_sorter = mysql_query($qry_get_sorter) or die(mysql_error());
	$sorter_data = mysql_fetch_assoc($sql_get_sorter);
	$sorter = $sorter_data['sorter'] + 1;

	$additional = array(
		'date_add' => SYS_DATE,
		'file_name' => $file_name,
		'status' => 1,
		'sorter' => $sorter
	);

	$product_data = formatting_query( array($gallery_id, $item_id, $additional, $temp_gallery), ',');
	
	# update the data
	$qry = "INSERT INTO ".GALLERY." SET ".$product_data;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
	
	
	
exit;



	$id_gallery = get_last_id('id_gallery', GALLERY);
	$gallery_id = formatting_query( array( array('id_gallery' => $id_gallery) ), '');
	
	# upload path
	$temp_upload_path = '../uploads/tmp-photo/';

	# error param for validate photo
	$error_count = 0;
	$width_error = '';
	$height_error = '';	
	$size_error = '';
	$type_error = '';

	# process button of slider
	if( isset($_POST['btn-gallery']) ) {
		foreach($_POST as $key=>$val) {
			include_once "../libraries/anti-injection.php";
			
			$each = anti_injection($val);
			
			$temp_gallery[$key] = $each;

			if( $key == 'btn-gallery' || empty($key) ) {
				unset($temp_gallery[$key]);
			}
		}

		$img_name = $_FILES['file_name']['name'];
		$img_temp = $_FILES['file_name']['tmp_name'];
		$img_size = $_FILES['file_name']['size'];
		$img_type = $_FILES['file_name']['type'];

		if( !empty($img_temp ) ) {
			$images_data = @getimagesize($img_temp);
			$img_width = $images_data[0];
			$img_height = $images_data[1];
			$gallery_images_type = json_decode($config['file_type'], true);
			$gallery_max_size = $config['max_size'] * 1024 * 1024;

			if( $img_width < $config['min_width'] || $img_width > $config['max_width'] )
			{
				$width_error = '<p class="error-msg">Lebar foto kurang atau lebih dari ukuran yang telah ditentukan.</p>';
				$error_count++;
			}
			if( $img_height < $config['min_height'] || $img_height > $config['max_height'] )
			{
				$height_error = '<p class="error-msg">Tinggi foto kurang atau lebih dari ukuran yang telah ditentukan.</p>';
				$error_count++;
			}
			if( !in_array($img_type, $gallery_images_type) )
			{
				$type_error = '<p class="error-msg">Tipe file yang diizinkan hanya JPG, PNG, dan GIF.</p>';
				$error_count++;
			}
			if( $img_size > $gallery_max_size )
			{
				$size_error = '<p class="error-msg">Ukuran file melebihi dari nilai yang ditentukan.</p>';
				$error_count++;
			}

			if( $error_count == 0 ) {
				if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
					$temp_photo = $temp_upload_path.$img_name;
					
					# name method
					switch( $config['name_format'] )
					{
						case 'generate':
							include_once "../libraries/random-generator.php";
							$new_name_file_name = new_image(10);
							break;
						case 'original':
							$new_name_file_name = strtolower($img_name);
							break;
					}
					
					# folder to save all photo
					$gallery_photo_path = '../uploads/'.$config['config_keyword'].'/'.$id_item.'/'.$id_gallery.'/';
					if( !is_dir($gallery_photo_path) ) {
						umask(0);
						mkdir( $gallery_photo_path, 0777, true);
					}
					
					# delete old photo
					@unlink($gallery_photo_path.$temp_gallery['file_name']);
					
					include_once "../libraries/image-cropper.php";
					# crop images for member photo
					$_file_name = _new_image($config['width'], $config['height'], $temp_photo, $gallery_photo_path, $new_name_file_name);
					$temp_gallery['file_name'] = $_file_name;
					@unlink($temp_photo);
				}
			}
		}

		if( $error_count == 0 ) {
			include_once '../libraries/query-format.php';

			# get last sorter value from gallery
			$qry_get_sorter = "SELECT MAX(sorter) AS sorter FROM ".GALLERY." WHERE ".$item_id;
			$sql_get_sorter = mysql_query($qry_get_sorter) or die(mysql_error());
			$sorter_data = mysql_fetch_assoc($sql_get_sorter);
			
			if( $sorter_data['sorter'] == 0 )
				{ $sorter = 1; }
			else
				{ $sorter = $sorter_data['sorter'] + 1; }

			# param
			$additional = array(
				'id_gallery' => $id_gallery,
				'id_item' => $id_item,
				'date_add' => SYS_DATE,
				'status' => 1,
				'sorter' => $sorter
			);
			$gallery_data = formatting_query( array($additional, $temp_gallery), ',');
			
			# update the data
			$qry = "INSERT INTO ".GALLERY." SET ".$gallery_data;
			$sql = mysql_query($qry) or die(mysql_error());
			if( $sql == true ) {
				header('location:gallery.php?'.str_replace(array(" ","'"),'',$item_id).'&gallery=added');
			}
		}
	}

?>