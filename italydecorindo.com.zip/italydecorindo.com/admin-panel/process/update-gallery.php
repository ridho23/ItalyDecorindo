<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_item_id = isset($_GET['id_item']) ? $_GET['id_item'] : "";
	$id_item = array('id_item' => $get_item_id);
	$item_data = formatting_query( array( $id_item ), '');

	$get_gallery_id = isset($_GET['id_gallery']) ? $_GET['id_gallery'] : "";
	$id_gallery = array('id_gallery' => $get_gallery_id);
	$gallery_data = formatting_query( array( $id_gallery ), '');

	$redirect = SITE_URL.'admin-panel/gallery.php?'.str_replace( array(' ',"'"),'',$item_data ).'&gallery=updated';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'gallery-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$gallery_photo_path = '../../uploads/'.$configs['config_keyword'].'/'.$get_item_id.'/'.$get_gallery_id.'/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_gallery[$key] = $each;

		if( $key == 'btn-update' ) {
			unset($temp_gallery[$key]);
		}
	}

	$img_name = $_FILES['file_name']['name'];
	$img_temp = $_FILES['file_name']['tmp_name'];
	$img_size = $_FILES['file_name']['size'];
	$img_type = $_FILES['file_name']['type'];

	if( !empty( $img_temp ) ) {
		if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
			$temp_photo = $temp_upload_path.$img_name;
			
			# name method
			switch( $configs['name_format'] )
			{
				case 'generate':
					include_once "../../libraries/random-generator.php";
					$file_name = new_image(10);
					break;
				case 'original':
					$file_name = strtolower($img_name);
					break;
			}
			
			# folder to save all photo
			if( !is_dir($gallery_photo_path) ) {
				umask(0);
				mkdir( $gallery_photo_path, 0777, true);
			}
			
			include_once "../../libraries/image-cropper.php";
			
			# crop images for member photo
			$file_name = _new_image($configs['width'], $configs['height'], $temp_photo, $gallery_photo_path, $file_name);
			@unlink($gallery_photo_path.$temp_gallery['file_name']);
			@unlink($temp_photo);
			$temp_gallery['file_name'] = $file_name;
		}
	} else {
		$temp_gallery['file_name'];
	}

	$additional = array( 'date_modified' => SYS_DATE );
	$profile_data = formatting_query( array($additional, $temp_gallery), ',');
	
	# update the data
	$qry = "UPDATE ".GALLERY." SET ".$profile_data." WHERE ".$gallery_data;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>