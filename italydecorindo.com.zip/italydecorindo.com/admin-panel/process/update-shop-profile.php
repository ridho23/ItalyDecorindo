<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_shop_id = $_GET['id'];
	$shop_id = array('id' => $get_shop_id);
	$id_shop = formatting_query( array( $shop_id ), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?profile=updated';
	
	# get upload config
	$qry_config = "SELECT config_keyword, width, height, name_format FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'profile-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# upload path
	$temp_upload_path = '../../uploads/tmp-photo/';
	$itd_logo_path = '../../assets/img/';

	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		$temp_shop[$key] = $each;

		if( $key == 'btn-update' ) {
			unset($temp_shop[$key]);
		}
	}

	$img_name = $_FILES['shop_logo']['name'];
	$img_temp = $_FILES['shop_logo']['tmp_name'];
	$img_size = $_FILES['shop_logo']['size'];
	$img_type = $_FILES['shop_logo']['type'];

	if( !empty( $img_temp ) ) {
		if( move_uploaded_file($img_temp, $temp_upload_path.$img_name) ) {
			$temp_photo = $temp_upload_path.$img_name;
			
			# name method
			switch( $configs['name_format'] )
			{
				case 'generate':
					include_once "../../libraries/random-generator.php";
					$new_name_shop_logo = new_image(10);
					break;
				case 'original':
					$new_name_shop_logo = strtolower($img_name);
					break;
			}
			
			# folder to save all photo
			if( !is_dir($itd_logo_path) ) {
				umask(0);
				mkdir( $itd_logo_path, 0777, true);
			}
			
			include_once "../../libraries/image-cropper.php";
			
			# crop images for member photo
			$shop_logo = _new_image($configs['width'], $configs['height'], $temp_photo, $itd_logo_path, $new_name_shop_logo);
			@unlink($itd_logo_path.$temp_shop['shop_logo']);
			@unlink($temp_photo);
			$temp_shop['shop_logo'] = $shop_logo;
		}
	} else {
		$temp_shop['shop_logo'];
	}

	$additional = array( 'date_modified' => SYS_DATE );
	$shop_data = formatting_query( array($additional, $temp_shop), ',');
	
	# update the data
	$qry = "UPDATE ".SHOP_PROFILE." SET ".$shop_data." WHERE ".$id_shop;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>