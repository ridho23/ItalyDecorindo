<?php
	session_start();
	require_once '../../auth/connection.php';
	include_once '../../libraries/anti-injection.php';
	include_once '../../libraries/query-format.php';
	
	# param
	$get_menu_id = $_GET['id_menu'];
	$menu_id = array('id_menu' => $get_menu_id);
	$id_menu = formatting_query( array( $menu_id ), '');

	$redirect = SITE_URL.'admin-panel/menus.php?menu=updated';
	
	# process
	foreach($_POST as $key=>$val) {
		$each = anti_injection($val);
		
		if( $key == 'menu_keyword' ) {
			$each = strtolower( str_replace(' ','-',$each) );
		}

		$temp_menu[$key] = $each;

		if( $key == 'btn-update' ) {
			unset($temp_menu[$key]);
		}
	}

	$menu_data = formatting_query( array($temp_menu), ',');
	
	# update the data
	$qry = "UPDATE ".MENUS." SET ".$menu_data." WHERE ".$id_menu;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>