<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	
	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# get sliders data
	$_sliders_images = array('id_slider','date_add','date_modified','slider_name','slider_caption','status','sorter');
	$qry_sliders = "SELECT ".implode(', ',$_sliders_images)." FROM ".SLIDERS_IMAGES." ORDER BY date_add DESC";
	$sql_sliders = mysql_query($qry_sliders) or die(mysql_error());

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">FOTO SLIDER</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/sliders.php'; ?>">Daftar Slider</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/add-new-slider.php'; ?>">Tambah Slider</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/slider-config.php'; ?>">Pengaturan</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12 msg-box">
                                    <?php
                                        if( isset($_GET['slider']) ) {
											switch( $_GET['slider'] ) {
												case 'added': $msg = 'Slider baru berhasil ditambahkan'; break;
												case 'deleted': $msg = 'Slider berhasil dihapus'; break;
												case 'updated': $msg = 'Slider berhasil diubah'; break;
											}
											
                                            echo '<div class="alert alert-success">'.$msg.'</div>';
                                        }
                                    ?>
                                </div>
                                <div class="col-md-12">
                                    <table id="data-sliders" class="display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Caption</th>
                                                <th>Tgl. Dibuat</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        	while( $slider = mysql_fetch_assoc($sql_sliders) ) {
												switch( $slider['status'] ) {
													case 0: $status = '<img src="'.BASE_URL.'img/i-inactive.png">'; break;
													case 1: $status = '<img src="'.BASE_URL.'img/i-active.png">'; break;
												}
										?>
                                        	<tr>
                                            	<td><?php echo $slider['id_slider']; ?></td>
                                            	<td><?php echo $slider['slider_caption']; ?></td>
                                            	<td><?php echo $slider['date_add']; ?></td>
                                            	<td><a data-id="<?php echo $slider['id_slider'].'-'.$slider['status']; ?>" class="_status"><?php echo $status; ?></a></td>
                                            	<td>
                                                	<a data-id="<?php echo $slider['id_slider']; ?>" class="btn btn-success _detail">Detail</a>
                                                    <a href="delete-slider.php?id_slider=<?php echo $slider['id_slider']; ?>&rdr=<?php echo $redirect; ?>" class="btn btn-danger" onClick="return confirm('Hapus slider ?');">
                                                    	Hapus
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL.'plugins/data-tables/css/jquery.dataTables.min.css'; ?>">
<!-- load jquery and other JS file to reduce load -->
<script src="<?php echo BASE_URL.'plugins/data-tables/js/jquery.dataTables.min.js'; ?> "></script>
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
    $('#data-sliders').DataTable();
	
	$("._detail").click(function() {
		$("#dialog_container").show();
	
		var slider_id = $(this).attr("data-id");
		$.post("ajax/get-detail-slider.php", { id_slider: slider_id }, function( result ) {
			$(".ajax_form").html( result );
			
			$("#form").validate({
				rules: {
					slider_caption: "required"
				},
				messages: {
					slider_caption: { required: "Isi caption pada foto slider" }
				}
			});

			<!-- ajax validation for photo -->
			$("#slider_name").change(function () {
				var keyword = $(this).attr("data-id");
				if(this.disabled) return alert('File upload not supported!');
				var F = this.files;
				//alert(F); return false;
				if(F && F[0]) {
					for(var i=0; i<F.length; i++)
					readImage( F[i], keyword );
				}
			});
		});
		
		$(".dialog_close").click(function() {
			$("#dialog_container").hide();
		});
	});
	
	$("._status").click(function() {
		var _status = $(this).attr("data-id");
		
		$.post("ajax/change-slider-status.php", { status: _status }, function( r ) {
			if( r == 'changed' ) {
				alert('Status slider berhasil diubah');
				location.reload(true);
			} else {
				alert('Status slider gagal diubah. Silahkan periksa dan setel kembali pengaturan jumlah tampilan pada slider.');
			}
		});
	});
});
</script>

<?php include 'tpl/footer.php'; ?>