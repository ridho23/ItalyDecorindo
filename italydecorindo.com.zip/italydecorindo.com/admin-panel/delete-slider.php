<?php
	require '../auth/connection.php';
	require 'auth.php';
	include_once '../libraries/query-format.php';

	# param
	$get_slider_id = isset($_GET['id_slider']) ? $_GET['id_slider'] : "";
	$slider_id = array( 'id_slider' => $get_slider_id );
	$id_slider = formatting_query( array($slider_id), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?slider=deleted';	

	# get related slider data
	$qry_get = "SELECT slider_name FROM ".SLIDERS_IMAGES." WHERE ".$id_slider;
	$sql_get = mysql_query($qry_get) or die(mysql_error());
	$get_data = mysql_fetch_assoc($sql_get);
	
	# slider path
	$path = '../uploads/slider-photo/'.$get_slider_id.'/';
	$image = $path.$get_data['slider_name'];
	
	# delete photo and its own path
	@unlink($image);
	rmdir($path);
	
	# delete data from database
	$qry = "DELETE FROM ".SLIDERS_IMAGES." WHERE ".$id_slider;
	$sql = mysql_query($qry) or die(mysql_error());
	if( $sql == true ) {
		header('location:'.$redirect);
	}
?>