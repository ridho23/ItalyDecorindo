<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');
	
	# for redirect url
	$delimiter = strpos($_SERVER['REQUEST_URI'], '?');
	if( empty($delimiter) ) {
		$redirect = urlencode($_SERVER['REQUEST_URI']);
	} else {
		$redirect = substr($_SERVER['REQUEST_URI'],0, $delimiter);
	}

	# get upload config
	$qry_config = "SELECT * FROM ".CONFIGS." WHERE config_name = 'display_slider'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">FOTO SLIDER</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li><a href="<?php echo SITE_URL.'admin-panel/sliders.php'; ?>">Daftar Slider</a></li>
                        <li><a href="<?php echo SITE_URL.'admin-panel/add-new-slider.php'; ?>">Tambah Slider</a></li>
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/slider-config.php'; ?>">Pengaturan</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-12">
                                    <?php if( isset($_GET['display_slider']) && $_GET['display_slider'] == 'updated' ) { ?>
                                        <div class="alert alert-success">
                                            Jumlah tampilan slider berhasil diubah
                                        </div>
									<?php } ?>
                                </div>
                                <div class="col-md-6">
                                    <div class="panel-body">
                                        <form action="process/update-display-slider.php?id_config=<?php echo $configs['id_config'].'&rdr='.$redirect; ?>" method="post" id="form">
                                            <div class="form-group">
                                                <label for="value">Jumlah Tampilan Slider *</label>
                                                <input class="form-control" type="text" name="value" id="value" autocomplete="off" value="<?php echo $configs['value']; ?>">
                                            </div>
                                            <button type="submit" class="btn btn-primary" name="btn-update">Update</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
	<!-- focus on first load -->
	$("#value").focus();
	
	<!-- start to validate profile form -->
	$("#form").validate({
		rules: {
			value: {
				required: true,
				number: true
			}
		},
		messages: {
			value: {
				required: "Isi jumlah slider",
				number: "Gunakan angka saja"
			}
		}
	});
});
</script>

<?php include 'tpl/footer.php'; ?>