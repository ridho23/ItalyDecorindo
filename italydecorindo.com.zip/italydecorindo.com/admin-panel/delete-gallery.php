<?php
	require '../auth/connection.php';
	require 'auth.php';
	include_once '../libraries/query-format.php';

	# param
	$id_gallery = isset($_GET['id_gallery']) ? $_GET['id_gallery'] : "";
	$gallery_id = array( 'id_gallery' => $id_gallery );
	$gallery_data = formatting_query( array($gallery_id), '');
	
	$id_item = isset($_GET['id_item']) ? $_GET['id_item'] : "";
	$item_id = array( 'id_item' => $id_item );
	$item_data = formatting_query( array($item_id), '');

	$rdr = isset($_GET['rdr']) ? $_GET['rdr'] : "";
	$redirect = $rdr.'?'.str_replace( array(' ',"'"),'',$item_data ).'&gallery=deleted';	

	# get gallery data
	$qry_get_gall = "SELECT file_name FROM ".GALLERY." WHERE ".$gallery_data;
	$sql_get_gall = mysql_query($qry_get_gall) or die(mysql_error());
	$gall_data = mysql_fetch_assoc($sql_get_gall);

	# gallery path
	$gall_path = '../uploads/gallery-photo/'.$id_item.'/'.$id_gallery.'/';
	$gall_image = $gall_path.$gall_data['file_name'];
	
	# delete gallery photo and its own path
	@unlink($gall_image);
	rmdir($gall_path);

	# delete gallery data from database
	$qry_del_gall = "DELETE FROM ".GALLERY." WHERE ".$gallery_data;
	$sql_del_gall = mysql_query($qry_del_gall) or die(mysql_error());

	if( $sql_del_gall == true ) {
		header('location:'.$redirect);
	}
?>