<?php
	session_start();
	require('../auth/connection.php');
	require('auth.php');

	# get upload config
	$qry_config = "SELECT min_width, min_height FROM ".UPLOADS_CONFIGS." WHERE config_keyword = 'product-photo'";
	$sql_config = mysql_query($qry_config) or die(mysql_error());
	$configs = mysql_fetch_assoc($sql_config);

	# get category product
	$sql_cat = mysql_query("SELECT id_category, category_name FROM ".CATEGORIES) or die(mysql_error());	

	# start the header
	include 'tpl/header.php';
?>

            <li>
                <a href="<?php echo SITE_URL.'admin-panel/dashboard.php'; ?>"><i class="fa fa-dashboard "></i>Dashboard</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/profile.php'; ?>"><i class="fa fa-user"></i>Admin User</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/message.php'; ?>"><i class="fa fa-envelope"></i>Pesan Masuk</a>
            </li>
            <li>
                <a class="active-menu" href="<?php echo SITE_URL.'admin-panel/products.php'; ?>"><i class="fa fa-briefcase"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo SITE_URL.'admin-panel/config.php'; ?>"><i class="fa fa-gear"></i>Pengaturan</a>
            </li>
        </ul>
    </div>
</nav>
<!-- /. NAV SIDE  -->

<div id="page-wrapper">
    <div id="page-inner" class="profile">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">TAMBAH PRODUK</h1>
            </div>
        </div>
		<!-- /. ROW  -->
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li><a href="<?php echo SITE_URL.'admin-panel/list-products.php'; ?>">Daftar Produk</a></li>
                        <li class="active"><a href="<?php echo SITE_URL.'admin-panel/add-new-product.php'; ?>">Tambah Produk</a></li>
                    </ul>
                
                    <div class="tab-content">
                        <div class="tab-pane fade active in">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="panel-body">
                                        <form action="process/save-new-product.php" method="post" enctype="multipart/form-data" id="form">
                                            <div class="form-group">
                                                <label for="product_logo">Foto Produk *</label>
                                                <input class="form-control" type="file" name="product_logo" id="product_logo" data-id="product-photo">
                                                <p class="help-block"><i>Ukuran foto minimal <?php echo $configs['min_width'].' x '.$configs['min_height']; ?></i></p>
                                        		<div id="err_msg_field"></div>
                                            </div>
                                            <div class="form-group">
                                                <label for="id_category">Kategori Produk *</label>
                                                <select id="id_category" name="id_category" class="form-control">
                                                	<option value="">Pilih Kategori</option>
                                                    <?php
                                                    	while( $get_cat = mysql_fetch_assoc($sql_cat) ) {
															if( isset($_POST['id_category']) ) {
																$selected = 'selected';
															} else {
																$selected = '';
															}
													?>
                                                    	<option value="<?php echo $get_cat['id_category']; ?>" <?php echo $selected; ?>><?php echo $get_cat['category_name']; ?></option>
													<?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="product_name">Nama Produk *</label>
                                                <input type="text" name="product_name" id="product_name" class="form-control" value="<?php if(isset($_POST['product_name'])) echo $_POST['product_name'];; ?>" autocomplete="off">
                                            </div>
                                            <input type="submit" id="btn" class="btn btn-primary" name="btn-product" value="Simpan">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<!-- load jquery and other JS file to reduce load -->
<script src="<?php echo BASE_URL.'js/reader-image.js'; ?>"></script>
<script src="<?php echo BASE_URL.'js/jquery.validate.js'; ?>"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#id_category").focus();

    <!-- start to validate profile form -->
    $("#form").validate({
        rules: {
            id_category: "required",
			product_logo: "required",
			product_name: "required"
        },
        messages: {
			id_category: { required: "Pilih kategori produk" },
            product_logo: { required: "Pilih gambar terlebih dahulu" },
            product_name: { required: "Isi nama produk" }
        }
    });

	<!-- ajax validation for photo -->
	$("#product_logo").change(function () {
		var keyword = $(this).attr("data-id");
		if(this.disabled) return alert('File upload not supported!');
		var F = this.files;
		//alert(F); return false;
		if(F && F[0]) {
			for(var i=0; i<F.length; i++)
			readImage( F[i], keyword );
		}
	});
});
</script>

<?php include 'tpl/footer.php'; ?>