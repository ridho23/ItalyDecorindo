<?php
	$_categories = array('id_category','category_keyword','category_name','category_logo');
	$_menus = array('menu_name','menu_url','sorter');
	$_sliders_images = array('id_slider','slider_name','slider_caption','sorter');
	$_contacts = array('shop_name','address','telp_1','telp_2','mobile_1','mobile_2','fax','email');
	
	# Contact
	$qry_contact = "SELECT ".implode(', ',$_contacts)." FROM ".SHOP_PROFILE;
	$sql_contact = mysql_query($qry_contact) or die(mysql_error());
	while($data_contact = mysql_fetch_assoc($sql_contact) ) { $contact[] = $data_contact; }	
	$contact = $contact[0];
	
	# Category
	$qry_category = "SELECT ".implode(', ',$_categories)." FROM ".CATEGORIES;
	$sql_category = mysql_query($qry_category) or die(mysql_error());	
	while( $category_section = mysql_fetch_assoc($sql_category) ) { $cat_section[] = $category_section; }
	
	# Header menu
	$qry_menu = "SELECT ".implode(', ',$_menus)." FROM ".MENUS." ORDER BY sorter ASC";
	$sql_menu = mysql_query($qry_menu) or die(mysql_error());
	
	# Slider Images config
	$qry_con_slider = "SELECT value FROM ".CONFIGS." WHERE config_name = 'display_slider'";
	$sql_con_slider = mysql_query($qry_con_slider) or die(mysql_error());
	$data_con_slider = mysql_fetch_assoc($sql_con_slider);
	$config_slider = $data_con_slider['value'];
	
	# Slider Images
	$qry_slider = "SELECT ".implode(', ',$_sliders_images)." FROM ".SLIDERS_IMAGES." WHERE status = 1 ORDER BY date_add DESC LIMIT ".$config_slider;
	$sql_slider = mysql_query($qry_slider) or die(mysql_error());
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Italy Decorindo | <?php echo $page_title; ?></title>
<link rel="icon" type="image/ico" href="<?php echo BASE_URL.'img/favicon.ico'; ?>">
<script src="<?php echo BASE_URL.'js/jquery-2.1.4.js'; ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/style.css">
<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/responsive.css">
<script>
$(document).ready(function() {
    $("#btn_toggle").click(function(){
		$("#hd-navbar").toggle();
	});
});
</script>
</head>

<body>
<!-- header section -->
<header>
    <!-- logo -->
    <a id="hd-logo" href="<?php echo SITE_URL; ?>"><img class="img-responsive" src="<?php echo BASE_URL.'img/logo.png'; ?>"></a>
    
    <!-- button for mobile display -->
    <div id="btn_toggle" class="pull-right">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    
    <!-- menus -->
    <ul id="hd-navbar" class="pull-right">
    <?php while($menu = mysql_fetch_assoc($sql_menu) ) { ?>
		<li><a class="img-a" href="<?php echo SITE_URL.$menu['menu_url']; ?>"><?php echo $menu['menu_name']; ?></a></li>
	<?php } ?>
    </ul>
    <div class="clearfix"></div>
</header>
<!-- end of header section -->

<?php if( $page_title == "Home" ) { ?>
	<!-- Setting for responsive slider -->
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL.'plugins/responsive-slider/responsiveslides.css'; ?>">
    <script src="<?php echo BASE_URL.'plugins/responsive-slider/responsiveslides.min.js'; ?>"></script>
    <script>
		$(document).ready(function() {
			$("#sliders").responsiveSlides({
				auto: true,
				pager: false,
				nav: true,
				speed: 1000,
				namespace: "callbacks",
				before: function () {
				  $('.events').append("<li>before event fired.</li>");
				},
				after: function () {
				  $('.events').append("<li>after event fired.</li>");
				}
			});
        });
    </script>

    <!-- slider images -->
	<div class="slider">
        <div class="callbacks_container">
            <ul class="rslides" id="sliders">
            <?php while( $slider = mysql_fetch_assoc($sql_slider) ) { ?>
                <li>
                    <img src="<?php echo UPLOADS.'slider-photo/'.$slider['id_slider'].'/'.$slider['slider_name']; ?>">
                    <p class="caption"><?php echo $slider['slider_caption']; ?></p>
                </li>
            <?php } ?>
            </ul>
        </div>
    </div>
    <!-- end of slider images -->
<?php } else { ?>
    <!-- banner section -->
    <div class="banner">
        <div class="inner-bg">
            <h2><?php echo $page_title; ?></h2>
        </div>
    </div>
    <!-- end of banner section -->
<?php } ?>
