<!-- footer section -->
<footer>
	<div class="inner-bg">
        <div class="fo-info">
            <ul>
                <li>
                    <img class="img-icon" src="<?php echo BASE_URL.'img/i-location.png';?>">
                    <span><?php echo $contact['address']; ?></span>
                </li>
                <li>
                    <img class="img-icon" src="<?php echo BASE_URL.'img/i-phone.png';?>">
                    <span><?php echo implode(' / ', array($contact['telp_1'],$contact['telp_2'])); ?></span>
                </li>
                <li>
                    <img class="img-icon" src="<?php echo BASE_URL.'img/i-email.png';?>">
                    <span><?php echo $contact['email']; ?></span>
                </li>
            </ul>
        </div>
        <hr>
        <div class="fo-license">
            <p>Copyright &copy; 2014 - <?php echo date('Y').' '. $contact['shop_name']; ?></p>
        </div>
	</div>
</footer>
<!-- end of footer section -->
</body>
</html>