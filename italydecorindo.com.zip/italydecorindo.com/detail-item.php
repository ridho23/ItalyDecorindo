<?php
	require 'auth/connection.php';
	if( isset($_GET['category']) && isset($_GET['product']) && isset($_GET['item']) )
	{
		$qry = "SELECT i.id_item, i.item_name, i.description, p.product_name FROM ".ITEMS_PRODUCTS." i, ".PRODUCTS." p WHERE i.id_product = p.id_product AND i.item_keyword = '".$_GET['item']."'";
		$sql = mysql_query($qry) or die(mysql_error());
		$data = mysql_fetch_assoc($sql);
		
		$_id_item = $data['id_item'];
		$_item = $data['item_name'];
		$_description = $data['description'];
		$_prod = $data['product_name'];
		$_cat = $_GET['category'];
	}
	else
	{
		header('location:'.SITE_URL.'error-404.php');
	}

	$page_title = implode(' &gt; ',array(ucwords($_cat),$_prod,$_item));
	
	# here is the header section
	include 'tpl/header.php';
?>

<!-- content section -->
<?php
	$_gallery = array('id_gallery','file_name','item_caption');
?>
<div class="content detail-product">
	<div class="container">
        <!-- heading -->
        <div class="description">
            <h3 class="heading"><?php echo $_item; ?></h3>
            <p class="paragraph"><?php echo $_description; ?></p>
        </div>

        <h3 class="heading">Galeri Foto</h3>
        <div class="row">
        	<?php
				$qry_gal = "SELECT ".implode(', ',$_gallery)." FROM ".GALLERY." WHERE id_item = '".$_id_item."' AND status = 1 ORDER BY sorter DESC";
				$sql_gal = mysql_query($qry_gal) or die(mysql_error());
				if( mysql_num_rows($sql_gal)>0 )
				{
	            	while( $gallery = mysql_fetch_assoc($sql_gal) ) {
						$gallery_image = UPLOADS.'gallery-photo/'.$_id_item.'/'.$gallery['id_gallery'].'/'.$gallery['file_name'];
						if( empty($gallery['file_name']) && !file_exists($path_image) )
							{ $gallery_image = BASE_URL.'img/default-gallery.jpg'; }
							
						if( empty($gallery['item_caption']) )
							{ $caption = 'Tidak ada caption untuk saat ini'; }
						else
							{ $caption = $gallery['item_caption']; }
			?>
                <div class="col-md-3 col-sm-6 col-xs-4">
                    <div class="frame-photo">
                        <!-- image logo -->
                        <img class="img-responsive" src="<?php echo $gallery_image; ?>">
                        <div class="item-caption"><?php echo $caption; ?></div>
                    </div>
                </div>
			<?php } } else { ?>
                <div class="container" style="text-align:center;">Maaf, foto tidak ditemukan atau tersedia saat ini.</div>
            <?php } ?>
        </div>

    </div>
</div>
<!-- end of content section -->

<?php include 'tpl/footer.php';?>