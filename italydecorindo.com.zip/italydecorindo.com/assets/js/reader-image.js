function readImage(file, photo_keyword ) {
	
    var reader = new FileReader();
    var image  = new Image();

    reader.readAsDataURL(file);  
    reader.onload = function(_file) {
        image.src    = _file.target.result;              // url.createObjectURL(file);
        image.onload = function() {
            var _width = this.width,
                _height = this.height,
                _type = file.type.split('/')[1],                           // ext only: // file.type.split('/')[1],
                _size = file.size,
				_keyword = photo_keyword;

			$.post('ajax/validate-photo.php', { width: _width, height: _height, type: _type, size: _size, keyword: _keyword }, function( err_msg ) {
				$("#err_msg_field").html( err_msg );
				$("#btn").click(function(e) {
					if( $("#error_count").val() == 0 ) {
						return true;
					} else {
						e.preventDefault();
						return false;
					}
				});
			});
			
        };
        image.onerror= function() {
            alert('Invalid file type: '+ file.type);
        };      
    };
}