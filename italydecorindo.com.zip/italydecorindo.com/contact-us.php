<?php
	require 'auth/connection.php';
	$page_title = 'Contact Us';
	
	# process data by pressing contact us button
	if( isset($_POST['btn-contact']) ) {
		include_once "libraries/anti-injection.php";
		
		foreach($_POST as $key=>$val) {
			$each = anti_injection($val);

			if( $key == 'sender_email' ) {
				$each = strtolower($each);
			}

			$temp_contact[$key] = $each;

			if( $key == 'btn-contact' ) {
				unset($temp_contact[$key]);
			}
		}

		include_once "libraries/random-generator.php";
		include_once "libraries/query-format.php";
		
		# get last saved id
		$contact_id = get_last_id('id', CONTACT_US);
		
		$additional = array(
			'id' => $contact_id,
			'date_sent' => SYS_DATE,
		);

		$post_contact = formatting_query(array($additional, $temp_contact), ',');
		
		# save to database
		$qry_save = "INSERT INTO ".CONTACT_US." SET ".$post_contact;
		$sql_save = mysql_query($qry_save) or die(mysql_error());
		if( $sql_save ==  true ) {
			# send to registered email
			require "assets/plugins/email-smtp/PHPMailerAutoload.php";
			$mail = new PHPMailer;
		
			$mail->isSMTP();                                      // Set mailer to use SMTP
			$mail->Host = 'server80302x.maintenis.com';  			  // Specify main and backup SMTP servers
			$mail->SMTPAuth = true;                               // Enable SMTP authentication
			$mail->Port = 587;                                    // TCP port to connect to
			$mail->Username = 'support@italydecorindo.com';         // SMTP username
			$mail->Password = '!74lyd3c012!nd0';                      // SMTP password
			$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
			$mail->SetFrom('support@italydecorindo.com', 'Italy Decorindo'); // Add a recipient
			$mail->addReplyTo($temp_contact['sender_email'], $temp_contact['sender']); // Add a recipient
			$mail->Subject = $temp_contact['email_subject'];
			$mail->MsgHTML(
				'<div marginwidth="0" marginheight="0" style="margin: 0px; padding:0 0 20px 0; background-color: rgb(221, 221, 221) ! important; width: 100% ! important;">
				<div style="margin: 0 auto;display: block; width: 600px;background: #fff;border-top: 5px solid #1184c2;border-bottom: 5px solid #1184c2;padding: 0 0 10px;">
					
					<span style="margin: 0 10px;display:block;">
						<h2 style="color: #1184c2;text-transform: capitalize;">Hai, Admin</h2>
					<br>
						'.$temp_contact['message'].'
					</span>
					<br>
					<br>
					<span style="margin: 0 10px;display:block;">
						<br>
						<br>
						<br>
						Keyshine Shopping Mall
						<br>
						<br>
						<br>
						<a href="www.keyshine.co.id" target="_blank" style="text-align: right;">www.keyshine.co.id</a>
					</span>
					</div>
				</div>'
			);
			$mail->addAddress('italydecorindo@gmail.com', 'Italy Decorindo'); // Add a recipient
			$mail->AddCC('ws14593.private@gmail.com', 'Italy Decorindo'); // Add CC

			if( $mail->send() ) {
				header('location:'.$_SERVER['PHP_SELF'].'?contact=success');
			} else {
				header('location:'.$_SERVER['PHP_SELF'].'?contact=failed');
			}
		}
	}

	# here is the header section
	include 'tpl/header.php';
?>

<!-- Setting for maps -->
<script src="<?php echo BASE_URL; ?>/js/jquery.validate.js"></script>
<script src="<?php echo BASE_URL; ?>/js/api-maps.js"></script>
<script>
	function initialize()
	{
		var mapsProp = {
			center:new google.maps.LatLng(-6.164455, 106.9009232),
			zoom:17,
			mapTypeId:google.maps.MapTypeId.ROADMAP,
		};	
		var maps = new google.maps.Map(document.getElementById("maps"), mapsProp);
	}
	google.maps.event.addDomListener(window, 'load', initialize);
	
$(document).ready(function() {
    <!-- validate contact us -->
	$("#form").validate({
		rules: {
			sender: "required",
			sender_email: {
				required: true,
				email: true
			},
			email_subject: "required",
			message: "required"
		},
		messages: {
			sender: { required: "Isi nama anda" },
			sender_email: {
				required: "Isi email anda",
				email: "Email tidak valid"
			},
			email_subject: { required: "Isi judul pesan anda" },
			message: { required: "Isi pesan anda" }
		}
	});
});
</script>
<!-- end of setting for maps -->

<!-- content section -->
<div class="content contact-us">
	<div class="container">
		<?php
            if( isset($_GET['contact']) ) {
                switch( $_GET['contact'] ) {
					case 'success': $msg = 'Terima kasih telah mengirimkan kritik dan saran. Pesan anda segera kami respon.'; break;
					case 'failed': $msg = 'Maaf terjadi kesalahan pada server kami, silahkan coba beberapa saat lagi.'; break;
				}
				
				echo '<div class="msg info">'.$msg.'</div>';
			}
		?>
    
        <!-- heading -->
        <h4 class="heading">Temukan kami di peta</h4>
        <!-- maps -->
        <div id="maps"></div>
        <!-- contact form -->
        <div class="contact-form">
            <div class="container">
                <!-- information -->
                <div class="cf-detail">
                    <ul>
                        <li>
                            <img class="img-icon" src="<?php echo BASE_URL.'img/i-location.png';?>">
                            <span><?php echo $contact['address']; ?></span>
                        </li>
                        <li>
                            <img class="img-icon" src="<?php echo BASE_URL.'img/i-phone.png';?>">
                            <span><?php echo implode(' / ', array($contact['telp_1'],$contact['telp_2'])); ?></span>
                        </li>
                        <li>
                            <img class="img-icon" src="<?php echo BASE_URL.'img/i-mobilephone.png';?>">
                            <span><?php echo $contact['mobile_1']; ?></span>
                        </li>
                        <li>
                            <img class="img-icon" src="<?php echo BASE_URL.'img/i-fax.png';?>">
                            <span><?php echo $contact['fax']; ?></span>
                        </li>
                        <li>
                            <img class="img-icon" src="<?php echo BASE_URL.'img/i-email.png';?>">
                            <span><?php echo $contact['email']; ?></span>
                        </li>
                    </ul>
                </div>
                <!-- form to be filled -->
                <div class="cf-form">
                    <h4 class="heading">Hubungi kami</h4>
                    <form id="form" method="post" action="">
                        <div class="cu-fields">
                            <label for="sender">Nama *</label>
                            <input type="text" id="sender" name="sender" placeholder="Nama Anda..." autocomplete="off">
                        </div>
                        <div class="cu-fields">
                            <label for="sender_email">Email *</label>
                            <input type="text" id="sender_email" name="sender_email" placeholder="Email Anda..." autocomplete="off">
                        </div>
                        <div class="cu-fields">
                            <label for="email_subject">Judul Pesan *</label>
                            <input type="text" id="email_subject" name="email_subject" placeholder="Judul Pesan..." autocomplete="off">
                        </div>
                        <div class="cu-fields">
                            <label for="message">Pesan *</label>
                            <textarea id="message" name="message" placeholder="Tuliskan pesan Anda disini..."></textarea>
                        </div>
                        <div class="cu-fields">
                            <input type="submit" id="btn-submit" class="btn btn-danger" name="btn-contact" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end of content section -->

<?php include 'tpl/footer.php';?>