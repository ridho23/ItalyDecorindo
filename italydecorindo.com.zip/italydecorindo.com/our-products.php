<?php
	require 'auth/connection.php';
	$page_title = 'Our Products';
	
	# here is the header section
	include 'tpl/header.php';
?>

<!-- content section -->
<?php
	$_products = array('id_product','product_keyword','product_name','product_logo','status');
?>
<div class="content our-products">
	<div class="container">
        <!-- main link -->
        <div class="main-link">
            <ul>
			<?php foreach( $cat_section as $keys ) { ?>
				<li><a href="<?php echo "#".$keys['category_keyword']; ?>" data-id="<?php echo $keys['category_keyword']; ?>"><?php echo $keys['category_name']; ?></a></li>
            <?php } ?>
            </ul>
        </div>        
        
		<?php foreach( $cat_section as $section ) { ?>
            <!-- wrapper of product > <?php echo $section['category_keyword']; ?> -->
            <div id="<?php echo $section['category_keyword']; ?>" class="categorize">
                <!-- heading -->
                <h3><?php echo $section['category_name']; ?></h3>
                <div class="row">
					<?php
						$qry_product = "SELECT ".implode(', ',$_products)." FROM ".PRODUCTS." WHERE id_category = '".$section['id_category']."' AND status = '1'";
						$sql_product = mysql_query($qry_product) or die(mysql_error());
						if( mysql_num_rows($sql_product)>0 )
						{
							while( $products = mysql_fetch_assoc($sql_product) ) {
								$path_image = UPLOADS.'product-photo/'.$products['id_product'].'/'.$products['product_logo'];
								if( empty($products['product_logo']) && !file_exists($path_image) )
									{ $path_image = BASE_URL.'img/default-product.jpg'; }
                    ?>
                    <div class="col-md-3 col-sm-6 col-xs-4">
                        <div class="item-wrapper">
                            <a class="item-link" href="<?php echo SITE_URL.'detail-product.php?category='.$section['category_keyword'].'&product='.$products['product_keyword']; ?>">
                                <!-- image logo -->
                                <img class="img-responsive" src="<?php echo $path_image; ?>">
                                <div class="product-name"><?php echo $products['product_name']; ?></div>
                            </a>
                        </div>
                    </div>
					<?php } } else { ?>
                        <div class="container" style="text-align:center;">Maaf, data tidak ditemukan atau tersedia saat ini.</div>
					<?php } ?>
                </div>
            </div>
            <!-- end for wrapper of product > <?php echo $section['product_keyword']; ?> -->
        <?php } ?>
    </div>
</div>
<!-- end of content section -->

<?php include 'tpl/footer.php';?>