<?php
	require 'auth/connection.php';
	$page_title = 'About Us';
	
	# here is the header section
	include 'tpl/header.php';
?>

<!-- content section -->
<?php
	$qry_au = "SELECT about_us FROM ".SHOP_PROFILE;
	$sql_au = mysql_query($qry_au) or die(mysql_error());
	$data = mysql_fetch_assoc($sql_au);
?>
<div class="content about-us">
	<div class="container">
        <!-- heading -->
        <h4 class="heading">Tentang Kami</h4>
        <!-- paragraph -->
        <p class="paragraph"><?php echo $data['about_us']; ?></p>
    </div>
</div>
<!-- end of content section -->

<?php include 'tpl/footer.php';?>