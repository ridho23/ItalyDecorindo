<?php
	require 'auth/connection.php';
	if( isset($_GET['category']) && isset($_GET['product']) )
	{
		$qry = "SELECT id_product, product_keyword, product_name FROM ".PRODUCTS." WHERE product_keyword = '".$_GET['product']."'";
		$sql = mysql_query($qry) or die(mysql_error());
		$data = mysql_fetch_assoc($sql);
		
		$_id_prod = $data['id_product'];
		$_keyword = $data['product_keyword'];
		$_prod = $data['product_name'];
		$_cat = $_GET['category'];
	}
	else
	{
		header('location:'.SITE_URL.'error-404.php');
	}
	
	$page_title = implode(' &gt; ',array(ucwords($_cat),$data['product_name']));
	
	# here is the header section
	include 'tpl/header.php';
?>

<!-- content section -->
<?php
	$_item_products = array('id_item','item_keyword','item_name','item_logo');
?>
<div class="content detail-product">
	<div class="container">
        <!-- heading -->
        <h3 class="heading">Jenis Produk : <?php echo $_prod; ?></h3>
        <div class="row">
        	<?php
				$qry_item = "SELECT ".implode(', ',$_item_products)." FROM ".ITEMS_PRODUCTS." WHERE id_product = '".$_id_prod."' AND status = 1";
				$sql_item = mysql_query($qry_item) or die(mysql_error());
				if( mysql_num_rows($sql_item)>0 )
				{
	            	while( $item = mysql_fetch_assoc($sql_item) ) {
						$item_image = UPLOADS.'item-product-photo/'.$_id_prod.'/'.$item['id_item'].'/'.$item['item_logo'];
						if( empty($item['item_logo']) && !file_exists($path_image) )
							{ $item_image = BASE_URL.'img/default-item-product.jpg'; }
			?>
                <div class="col-md-3 col-sm-6 col-xs-4">
                    <div class="frame-photo">
                        <a class="item-link" href="<?php echo SITE_URL.'detail-item.php?category='.$_cat.'&product='.$_keyword.'&item='.$item['item_keyword']; ?>">
                            <!-- image logo -->
                            <img class="img-responsive" src="<?php echo $item_image; ?>">
                            <div class="item-name"><?php echo $item['item_name']; ?></div>
                        </a>
                    </div>
                </div>
			<?php } } else { ?>
                <div class="container" style="text-align:center;">Maaf, data tidak ditemukan atau tersedia saat ini.</div>
            <?php } ?>
        </div>
    </div>
</div>
<!-- end of content section -->

<?php include 'tpl/footer.php';?>