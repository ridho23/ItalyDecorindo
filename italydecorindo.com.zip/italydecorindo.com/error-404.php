<?php
	require 'auth/connection.php';
	$page_title = 'Error 404';
	
	# here is the header section
	include 'tpl/header.php';
?>

<!-- content section -->
<div class="content error_404">
	<div class="container">
        <!-- paragraph -->
        <p class="paragraph">Maaf, halaman yang Anda cari tidak ditemukan atau sudah kadaluarsa.</p>
    </div>
</div>
<!-- end of content section -->

<?php include 'tpl/footer.php';?>