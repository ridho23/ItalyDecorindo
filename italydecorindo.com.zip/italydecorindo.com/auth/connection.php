<?php
#	error_reporting(0);
	date_default_timezone_set("Asia/Jakarta");

	# open connection setting
	$conn_config= array(
		'hostname' => 'localhost',
		'username' => 'root',
		'password' => '',
		'database' => 'k8417893_italydecorindo'
	);
	
	define('HOSTNAME', $conn_config['hostname']);
	define('USERNAME', $conn_config['username']);
	define('PASSWORD', $conn_config['password']);
	define('DATABASE', $conn_config['database']);
	
	mysql_connect(HOSTNAME,USERNAME,PASSWORD) or die('Connection could not be established : '.mysql_error());
	mysql_select_db(DATABASE) or die('No selected database :'.mysql_error());
	
	# set relative url
	$site_url = '/italydecorindo.com/';
	$base_url = '/italydecorindo.com/assets/';
	$path_url = '/italydecorindo.com/uploads/';

	define('SITE_URL', $site_url);
	define('BASE_URL', $base_url);
	define('UPLOADS', $path_url);
	
	# etc
	define('SYS_DATE', date('Y-m-d H:i:s'));
	define('LOGGED_IN_COOKIE_NAME', 'itd_logged_in');
	define('LOGGED_IN_COOKIE_VALUE', md5(hash('SHA256',md5(LOGGED_IN_COOKIE_NAME))) );
	
	# set table name from database
	define('PREFIX','itd_');
	define('AUSERS', PREFIX.'ausers');
	define('CATEGORIES', PREFIX.'categories');
	define('CONFIGS', PREFIX.'configs');
	define('CONTACT_US', PREFIX.'contact_us');
	define('GALLERY', PREFIX.'gallery');
	define('ITEMS_PRODUCTS', PREFIX.'items_products');
	define('MENUS', PREFIX.'menus');
	define('PRODUCTS', PREFIX.'products');
	define('SHOP_PROFILE', PREFIX.'shop_profile');
	define('SLIDERS_IMAGES', PREFIX.'sliders_images');
	define('UPLOADS_CONFIGS', PREFIX.'uploads');
?>