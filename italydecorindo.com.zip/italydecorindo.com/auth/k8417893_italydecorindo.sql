-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2016 at 02:36 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `k8417893_italydecorindo`
--

-- --------------------------------------------------------

--
-- Table structure for table `itd_ausers`
--

CREATE TABLE IF NOT EXISTS `itd_ausers` (
  `auser_id` tinyint(1) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `auser_logo` varchar(100) NOT NULL,
  `status` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_ausers`
--

INSERT INTO `itd_ausers` (`auser_id`, `date_add`, `date_modified`, `name`, `username`, `password`, `auser_logo`, `status`) VALUES
(1, '2015-10-26 22:22:57', '2015-12-22 00:43:44', 'Admin ITD', 'admin', '692e8c17ddc49aac7c5901588b5a3e97', '966e792824.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `itd_categories`
--

CREATE TABLE IF NOT EXISTS `itd_categories` (
  `id_category` tinyint(1) NOT NULL,
  `category_keyword` varchar(30) NOT NULL,
  `category_name` varchar(30) NOT NULL,
  `category_logo` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_categories`
--

INSERT INTO `itd_categories` (`id_category`, `category_keyword`, `category_name`, `category_logo`) VALUES
(1, 'interior-design', 'Interior Design', '1f064546e2.jpg'),
(2, 'eksterior', 'Eksterior', '4aa3d05803.jpg'),
(3, 'jasa-service', 'Jasa &amp; Service', 'bg-jasa-service.png');

-- --------------------------------------------------------

--
-- Table structure for table `itd_configs`
--

CREATE TABLE IF NOT EXISTS `itd_configs` (
  `id_config` int(3) NOT NULL,
  `config_keyword` varchar(50) DEFAULT NULL,
  `config_name` varchar(50) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `itd_configs`
--

INSERT INTO `itd_configs` (`id_config`, `config_keyword`, `config_name`, `value`) VALUES
(1, 'slider-photo', 'display_slider', '5');

-- --------------------------------------------------------

--
-- Table structure for table `itd_contact_us`
--

CREATE TABLE IF NOT EXISTS `itd_contact_us` (
  `id` int(11) NOT NULL,
  `date_sent` datetime NOT NULL,
  `sender` varchar(50) NOT NULL,
  `sender_email` varchar(50) NOT NULL,
  `email_subject` varchar(100) NOT NULL,
  `message` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `itd_gallery`
--

CREATE TABLE IF NOT EXISTS `itd_gallery` (
  `id_gallery` int(11) NOT NULL,
  `id_item` int(11) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `item_caption` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sorter` int(1) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_gallery`
--

INSERT INTO `itd_gallery` (`id_gallery`, `id_item`, `date_add`, `date_modified`, `file_name`, `item_caption`, `status`, `sorter`) VALUES
(3, 1, '2015-12-23 02:09:17', '2015-12-23 02:23:29', '381d877a95.jpg', 'Testing doang kalee, ga perlu panik.', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `itd_items_products`
--

CREATE TABLE IF NOT EXISTS `itd_items_products` (
  `id_item` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `item_keyword` varchar(50) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `description` mediumtext NOT NULL,
  `item_logo` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_items_products`
--

INSERT INTO `itd_items_products` (`id_item`, `id_product`, `date_add`, `date_modified`, `item_keyword`, `item_name`, `description`, `item_logo`, `status`) VALUES
(1, 6, '2015-12-23 00:16:34', '2015-12-23 01:21:41', 'mariah-jackson', 'mariah jackson', '&lt;p&gt;Hold my hand, open arms&lt;/p&gt;', '8696ff1ad0.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `itd_menus`
--

CREATE TABLE IF NOT EXISTS `itd_menus` (
  `id_menu` int(1) NOT NULL,
  `menu_keyword` varchar(30) NOT NULL,
  `menu_name` varchar(30) NOT NULL,
  `menu_url` varchar(50) NOT NULL,
  `sorter` int(3) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_menus`
--

INSERT INTO `itd_menus` (`id_menu`, `menu_keyword`, `menu_name`, `menu_url`, `sorter`) VALUES
(1, 'beranda', 'Beranda', '', 1),
(2, 'our-products', 'Our Products', 'our-products.php', 2),
(3, 'about-us', 'About Us', 'about-us.php', 3),
(4, 'contact-us', 'Contact Us', 'contact-us.php', 4);

-- --------------------------------------------------------

--
-- Table structure for table `itd_products`
--

CREATE TABLE IF NOT EXISTS `itd_products` (
  `id_product` int(11) NOT NULL,
  `id_category` tinyint(1) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `product_keyword` varchar(50) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_logo` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_products`
--

INSERT INTO `itd_products` (`id_product`, `id_category`, `date_add`, `date_modified`, `product_keyword`, `product_name`, `product_logo`, `status`) VALUES
(5, 1, '2015-12-16 02:34:10', '2015-12-22 20:24:10', 'gordyn', 'Gordyn', '0afa3ad942.jpg', 1),
(2, 3, '2015-12-16 00:46:10', '2015-12-22 21:39:47', 'kali-ini-bener-dah', 'Kali ini bener dah', '9e8dad7ac5.jpg', 1),
(7, 2, '2015-12-23 03:06:21', '0000-00-00 00:00:00', 'kwkwkkw', 'kwkwkkw', '97b5d7bd6b.jpg', 1),
(4, 1, '2015-12-16 02:02:21', '2015-12-22 21:39:19', 'tai-kucing', 'Tai Kucing', '59d1f7fbad.jpg', 0),
(6, 2, '2015-12-22 20:46:09', '0000-00-00 00:00:00', 'tesitng', 'Tesitng', 'b40483df1d.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `itd_shop_profile`
--

CREATE TABLE IF NOT EXISTS `itd_shop_profile` (
  `id` tinyint(1) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `shop_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `telp_1` varchar(20) NOT NULL,
  `telp_2` varchar(20) NOT NULL,
  `mobile_1` varchar(20) NOT NULL,
  `mobile_2` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `about_us` text NOT NULL,
  `lat` decimal(10,0) NOT NULL,
  `lon` decimal(10,0) NOT NULL,
  `shop_logo` varchar(20) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_shop_profile`
--

INSERT INTO `itd_shop_profile` (`id`, `date_add`, `date_modified`, `shop_name`, `address`, `telp_1`, `telp_2`, `mobile_1`, `mobile_2`, `fax`, `email`, `about_us`, `lat`, `lon`, `shop_logo`) VALUES
(1, '2015-10-26 23:47:29', '2015-12-22 01:07:44', 'Italy Decorindo', 'Jl. Boulevard Raya FW1 No. 6 Kelapa Gading, Jakarta Utara 14240', '0216413342', '02164712317', '08998349177', '089618613360', '0213501846', 'italydecorindo@gmail.com', '<p>Pokoknya disini isi aja sesuka hati.</p>\r\n<p>&nbsp;</p>\r\n<p>Boleh sebebas-bebasnya.</p>\r\n<p>&nbsp;</p>\r\n<p>Thank you</p>', '-6', '107', 'logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `itd_sliders_images`
--

CREATE TABLE IF NOT EXISTS `itd_sliders_images` (
  `id_slider` int(3) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `slider_name` varchar(100) NOT NULL,
  `slider_caption` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sorter` int(3) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_sliders_images`
--

INSERT INTO `itd_sliders_images` (`id_slider`, `date_add`, `date_modified`, `slider_name`, `slider_caption`, `status`, `sorter`) VALUES
(1, '2015-12-13 03:17:51', '2015-12-22 00:01:19', '5052d1ac4d.jpg', 'Slider 1 (Satu), Udah diganti fotonya tauuuuuuu', 0, 1),
(2, '2015-12-13 03:18:10', '2016-01-16 20:30:34', '043ce3019f.jpg', 'Masa ga boleh kosong sih.. Ckckckck ...', 0, 2),
(3, '2015-12-13 03:18:42', '2015-12-15 21:25:47', 'be355e8d32.jpg', 'Slider 3', 1, 3),
(4, '2015-12-13 03:18:50', '0000-00-00 00:00:00', 'a2737a7413.jpg', 'Slider 4', 1, 4),
(6, '2015-12-21 21:36:51', '0000-00-00 00:00:00', '2886bcc5ca.jpg', 'Ini hanya testing belaka, hahaha', 1, 6),
(7, '2015-12-22 00:45:26', '0000-00-00 00:00:00', '821b7b80bd.jpg', 'Hahah ahha ha ah aha h skhv', 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `itd_uploads`
--

CREATE TABLE IF NOT EXISTS `itd_uploads` (
  `id_upload` int(3) NOT NULL,
  `config_keyword` varchar(50) NOT NULL,
  `config_name` varchar(50) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `min_width` int(11) NOT NULL,
  `min_height` int(11) NOT NULL,
  `max_width` int(11) NOT NULL,
  `max_height` int(11) NOT NULL,
  `max_size` int(11) NOT NULL,
  `name_format` enum('generate','original') NOT NULL,
  `file_type` text NOT NULL,
  `default_img` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itd_uploads`
--

INSERT INTO `itd_uploads` (`id_upload`, `config_keyword`, `config_name`, `width`, `height`, `min_width`, `min_height`, `max_width`, `max_height`, `max_size`, `name_format`, `file_type`, `default_img`) VALUES
(1, 'slider-photo', 'Foto Slider Image', 1600, 520, 1100, 550, 5000, 5000, 3, 'generate', '{"jpg":"jpeg","png":"png"}', 'default_slider-photo.jpg'),
(2, 'product-photo', 'Foto Produk', 400, 520, 500, 650, 5000, 5000, 5, 'generate', '{"jpg":"jpeg","png":"png"}', 'default_product-photo.jpg'),
(3, 'index-photo', 'Foto Menu', 520, 400, 650, 500, 5000, 5000, 5, 'generate', '{"jpg":"jpeg","png":"png","gif":"gif"}', 'default_index-photo.jpg'),
(4, 'auser-logo', 'Foto Admin', 200, 200, 300, 300, 1000, 1000, 1, 'generate', '{"jpg":"jpeg","png":"png"}', 'default_auser-logo.jpg'),
(6, 'gallery-photo', 'Foto Gallery', 400, 400, 500, 500, 5000, 5000, 5, 'generate', '{"jpg":"jpeg","png":"png"}', 'default_gallery-photo.jpg'),
(5, 'item-product-photo', 'Foto Item Produk', 400, 400, 500, 500, 5000, 5000, 5, 'generate', '{"jpg":"jpeg","png":"png"}', 'default_item-product-photo.jpg'),
(7, 'profile-photo', 'Logo Italy', 605, 75, 650, 80, 1000, 300, 1, 'generate', '{"gif":"gif"}', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `itd_ausers`
--
ALTER TABLE `itd_ausers`
  ADD PRIMARY KEY (`auser_id`);

--
-- Indexes for table `itd_categories`
--
ALTER TABLE `itd_categories`
  ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `itd_configs`
--
ALTER TABLE `itd_configs`
  ADD PRIMARY KEY (`id_config`);

--
-- Indexes for table `itd_contact_us`
--
ALTER TABLE `itd_contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itd_gallery`
--
ALTER TABLE `itd_gallery`
  ADD PRIMARY KEY (`id_gallery`);

--
-- Indexes for table `itd_items_products`
--
ALTER TABLE `itd_items_products`
  ADD PRIMARY KEY (`id_item`);

--
-- Indexes for table `itd_menus`
--
ALTER TABLE `itd_menus`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indexes for table `itd_products`
--
ALTER TABLE `itd_products`
  ADD PRIMARY KEY (`id_product`);

--
-- Indexes for table `itd_shop_profile`
--
ALTER TABLE `itd_shop_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itd_sliders_images`
--
ALTER TABLE `itd_sliders_images`
  ADD PRIMARY KEY (`id_slider`);

--
-- Indexes for table `itd_uploads`
--
ALTER TABLE `itd_uploads`
  ADD PRIMARY KEY (`id_upload`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `itd_ausers`
--
ALTER TABLE `itd_ausers`
  MODIFY `auser_id` tinyint(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `itd_categories`
--
ALTER TABLE `itd_categories`
  MODIFY `id_category` tinyint(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `itd_configs`
--
ALTER TABLE `itd_configs`
  MODIFY `id_config` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `itd_contact_us`
--
ALTER TABLE `itd_contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `itd_gallery`
--
ALTER TABLE `itd_gallery`
  MODIFY `id_gallery` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `itd_items_products`
--
ALTER TABLE `itd_items_products`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `itd_menus`
--
ALTER TABLE `itd_menus`
  MODIFY `id_menu` int(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `itd_products`
--
ALTER TABLE `itd_products`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `itd_shop_profile`
--
ALTER TABLE `itd_shop_profile`
  MODIFY `id` tinyint(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `itd_sliders_images`
--
ALTER TABLE `itd_sliders_images`
  MODIFY `id_slider` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `itd_uploads`
--
ALTER TABLE `itd_uploads`
  MODIFY `id_upload` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
