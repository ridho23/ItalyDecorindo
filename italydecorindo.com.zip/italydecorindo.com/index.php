<?php
	require 'auth/connection.php';
	$page_title = 'Home';
	
	# here is the header section
	include 'tpl/header.php';
?>

<!-- content section -->
<div class="content home">
	<div class="container">
    	<div class="row">
        	<?php foreach( $cat_section as $category ) { ?>
                <div class="col-md-4 col-sm-4">
                    <div class="hm-main-menu">
                        <a href="<?php echo SITE_URL.'our-products.php#'.$category['category_keyword']; ?>">
                            <img class="img-responsive" src="<?php echo UPLOADS.'index-photo/'.$category['category_logo']; ?>">
                            <div class="hm-caption"><p><?php echo $category['category_name']; ?></p></div>
                        </a>
                    </div>
                </div>
			<?php } ?>        
        </div>
    </div>
</div>
<!-- end of content section -->

<?php include 'tpl/footer.php';?>